# AutoPilot (Android — Kotlin & Jetpack Compose)

A native Android rewrite of **AutoPilot** built with **Kotlin**, **Jetpack Compose**, **Material 3**, **Room**, **DataStore**, **WorkManager**, and **Android WebView**.

## Features

- **Multi-Tab WebView Automation Engine (`AutomationEngine` + `AutomationForegroundService`)**
  - Supports up to 10 concurrent WebView tabs with real-time live preview switching (`AndroidView` container attach/detach).
  - Configurable automation modes (`FULL_AUTO`, `REFRESH_ONLY`, `SCROLL_ONLY`, `SCRIPT_ONLY`) with refresh interval, scroll speed, deep-scroll toggle, user-agent rotation, and custom JavaScript execution.
  - Persistent foreground service (`foregroundServiceType="dataSync"`) with notification controls (**Pause**, **Resume**, **Stop**) and low-memory auto-pause safeguards.
- **Stealth & Network Controls**
  - **Device Fingerprints**: Manage and rotate device profiles (User-Agent, platform, viewport, hardware concurrency, device memory, WebGL vendor/renderer, canvas noise, WebRTC policy). Includes seeded presets and custom profile creation.
  - **Proxy Pool**: Add HTTP/HTTPS/SOCKS4/SOCKS5 proxies, filter by country, run real TCP socket latency probes (`ProxyHealthChecker`), and apply `androidx.webkit.ProxyController` overrides when supported by the device WebView.
  - **Environment Diagnostics**: Inspect root/Magisk/Zygisk/LSPosed environment indicators (`RootEnvironmentDetector`).
- **Activity, History & Scheduling**
  - Live telemetry event feed with category filters.
  - Room-persisted session history with one-tap configuration reload.
  - Scheduled automation tasks executed via `WorkManager` (`ScheduleWorker`), plus boot-time resume and periodic sync workers (`BootReceiver`, `SessionResumeWorker`, `SessionSyncWorker`).
- **Settings & Adaptive UI**
  - Local operator profile and default automation preferences stored in Jetpack DataStore (`UserSettingsRepository`).
  - Dynamic dark/light Material 3 theme using bundled `Poppins` and `JetBrains Mono` typography.
  - Adaptive navigation (`NavigationBar` on compact screens, `NavigationRail` on medium/expanded screens).

## Architecture

- `domain/model/` — Core domain models (`AutomationConfig`, `AutomationSession`, `EngineState`, `AutomationEvent`, `DeviceFingerprint`, `ProxyInfo`, `RootEnvironment`, `ScheduledTask`, `UserSettings`).
- `data/local/` — Room database (`AppDatabase`, `AutoPilotDao`, entities), `UserSettingsRepository` (DataStore), and `AutoPilotRepository`.
- `automation/` — `AutomationEngine`, `AutomationForegroundService`, `StealthScriptGenerator`, `ProxyHealthChecker`, `RootEnvironmentDetector`, `BootReceiver`, and WorkManager workers.
- `ui/` — Material 3 theme, `AutoPilotViewModel`, type-safe Navigation Compose routes, and `EngineScreen`, `ActivityScreen`, `StealthScreen`, and `SettingsScreen`.

## Build

- Kotlin + Jetpack Compose with Gradle Kotlin DSL (`compileSdk = 36`, `minSdk = 31`, `targetSdk = 36`).
- Build debug APK:
  ```bash
  gradle assembleDebug
  ```
