package com.autopilot.app.automation

import android.annotation.SuppressLint
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewFeature
import com.autopilot.app.domain.model.ProxyInfo
import com.autopilot.app.domain.model.ProxyProtocol
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executor

object ProxyHealthChecker {

    suspend fun probe(proxy: ProxyInfo, timeoutMs: Int = 3500): ProxyInfo = withContext(Dispatchers.IO) {
        val start = System.nanoTime()
        val now = System.currentTimeMillis()
        var socket: Socket? = null
        try {
            socket = Socket()
            socket.connect(InetSocketAddress(proxy.host, proxy.port), timeoutMs)
            val elapsedMs = ((System.nanoTime() - start) / 1_000_000L).coerceAtLeast(1L)
            proxy.copy(
                latencyMs = elapsedMs,
                isAlive = true,
                lastChecked = now,
                failureCount = 0
            )
        } catch (_: Exception) {
            proxy.copy(
                latencyMs = -1L,
                isAlive = false,
                lastChecked = now,
                failureCount = proxy.failureCount + 1
            )
        } finally {
            runCatching { socket?.close() }
        }
    }

    @SuppressLint("RequiresFeature")
    fun applyWebViewProxy(proxy: ProxyInfo?): Boolean {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            return false
        }
        val controller = ProxyController.getInstance()
        val executor = Executor { it.run() }
        return if (proxy == null) {
            runCatching { controller.clearProxyOverride(executor) {} }.isSuccess
        } else {
            val scheme = when (proxy.protocol) {
                ProxyProtocol.HTTP -> "http"
                ProxyProtocol.HTTPS -> "https"
                ProxyProtocol.SOCKS4 -> "socks4"
                ProxyProtocol.SOCKS5 -> "socks5"
            }
            val config = ProxyConfig.Builder()
                .addProxyRule("$scheme://${proxy.host}:${proxy.port}")
                .build()
            runCatching { controller.setProxyOverride(config, executor) {} }.isSuccess
        }
    }
}
