package defpackage;

import com.autopilot.app.domain.model.ProxyInfo;
import com.autopilot.app.domain.model.ProxyProtocol;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import okhttp3.ResponseBody;
import okhttp3.internal.connection.RealCall;

/* JADX INFO: compiled from: r8-map-id-9e9d01703a38bd5606c48ed47f0b7de32f47adb46ac9f9fd37ba7f9d580026b3 */
/* JADX INFO: loaded from: classes.dex */
public final class jx0 extends x33 implements fy0 {
    public final /* synthetic */ byte a;
    public final /* synthetic */ ox0 b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ jx0(ox0 ox0Var, t20 t20Var, byte b) {
        super(2, t20Var);
        this.a = b;
        this.b = ox0Var;
    }

    @Override // defpackage.sk
    public final t20 create(Object obj, t20 t20Var) {
        byte b = this.a;
        ox0 ox0Var = this.b;
        switch (b) {
            case 0:
                return new jx0(ox0Var, t20Var, (byte) 0);
            case 1:
                return new jx0(ox0Var, t20Var, (byte) 1);
            case 2:
                return new jx0(ox0Var, t20Var, (byte) 2);
            default:
                return new jx0(ox0Var, t20Var, (byte) 3);
        }
    }

    @Override // defpackage.fy0
    public final Object invoke(Object obj, Object obj2) {
        byte b = this.a;
        lh3 lh3Var = lh3.a;
        b40 b40Var = (b40) obj;
        t20 t20Var = (t20) obj2;
        switch (b) {
            case 0:
                break;
            case 1:
                break;
            case 2:
                break;
        }
        return ((jx0) create(b40Var, t20Var)).invokeSuspend(lh3Var);
    }

    @Override // defpackage.sk
    public final Object invokeSuspend(Object obj) {
        String strN;
        ua1 jsonArray;
        dc1 jsonPrimitive;
        String content;
        cb1 cb1Var;
        dc1 jsonPrimitive2;
        String content2;
        Integer numW;
        String content3;
        dc1 jsonPrimitive3;
        String strN2;
        String strN3;
        String strN4;
        byte b = this.a;
        int i = 0;
        ox0 ox0Var = this.b;
        zk0 zk0Var = zk0.a;
        switch (b) {
            case 0:
                cj0.I(obj);
                try {
                    ResponseBody responseBody = new RealCall(ox0Var.d, ox0.f("https://proxylist.geonode.com/api/proxy-list?limit=40&page=1&sort_by=lastChecked&sort_type=desc&protocols=http%2Chttps")).c().n;
                    if (responseBody == null || (strN = responseBody.n()) == null) {
                        return zk0Var;
                    }
                    ArrayList arrayList = new ArrayList();
                    cb1 cb1Var2 = (cb1) db1.getJsonObject(ox0Var.c.parseToJsonElement(strN)).get((Object) "data");
                    if (cb1Var2 == null || (jsonArray = db1.getJsonArray(cb1Var2)) == null) {
                        return zk0Var;
                    }
                    Iterator<cb1> it = jsonArray.iterator();
                    while (it.hasNext()) {
                        zb1 jsonObject = db1.getJsonObject(it.next());
                        cb1 cb1Var3 = (cb1) jsonObject.get((Object) "ip");
                        if (cb1Var3 != null && (jsonPrimitive = db1.getJsonPrimitive(cb1Var3)) != null && (content = jsonPrimitive.getContent()) != null && (cb1Var = (cb1) jsonObject.get((Object) "port")) != null && (jsonPrimitive2 = db1.getJsonPrimitive(cb1Var)) != null && (content2 = jsonPrimitive2.getContent()) != null && (numW = g23.W(content2)) != null) {
                            int iIntValue = numW.intValue();
                            cb1 cb1Var4 = (cb1) jsonObject.get((Object) "country");
                            if (cb1Var4 == null || (jsonPrimitive3 = db1.getJsonPrimitive(cb1Var4)) == null || (content3 = jsonPrimitive3.getContent()) == null) {
                                content3 = "";
                            }
                            String str = content3;
                            if (1 <= iIntValue && iIntValue < 65536 && !z13.g0(content)) {
                                arrayList.add(new ProxyInfo(content, iIntValue, ProxyProtocol.HTTP, str, 0L, false, 0L, 0, 240, null));
                            }
                        }
                    }
                    return ru.k0(30, arrayList);
                } catch (Exception unused) {
                    return zk0Var;
                }
            case 1:
                cj0.I(obj);
                try {
                    ResponseBody responseBody2 = new RealCall(ox0Var.d, ox0.f("https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt")).c().n;
                    if (responseBody2 == null || (strN2 = responseBody2.n()) == null) {
                        return zk0Var;
                    }
                    List listK0 = z13.k0(strN2);
                    ArrayList arrayList2 = new ArrayList();
                    for (Object obj2 : listK0) {
                        String str2 = (String) obj2;
                        if (!z13.g0(str2) && !g23.U(str2, "#", false)) {
                            arrayList2.add(obj2);
                        }
                    }
                    ArrayList arrayList3 = new ArrayList();
                    int size = arrayList2.size();
                    while (i < size) {
                        Object obj3 = arrayList2.get(i);
                        i++;
                        ProxyInfo proxyInfoD = ox0.d((String) obj3);
                        if (proxyInfoD != null) {
                            arrayList3.add(proxyInfoD);
                        }
                    }
                    return ru.k0(30, arrayList3);
                } catch (Exception unused2) {
                    return zk0Var;
                }
            case 2:
                cj0.I(obj);
                try {
                    ResponseBody responseBody3 = new RealCall(ox0Var.d, ox0.f("https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=5000&country=all&ssl=yes&anonymity=all")).c().n;
                    if (responseBody3 == null || (strN3 = responseBody3.n()) == null) {
                        return zk0Var;
                    }
                    List listK1 = z13.k0(strN3);
                    ArrayList arrayList4 = new ArrayList();
                    for (Object obj4 : listK1) {
                        if (!z13.g0((String) obj4)) {
                            arrayList4.add(obj4);
                        }
                    }
                    ArrayList arrayList5 = new ArrayList();
                    int size2 = arrayList4.size();
                    while (i < size2) {
                        Object obj5 = arrayList4.get(i);
                        i++;
                        ProxyInfo proxyInfoD2 = ox0.d((String) obj5);
                        if (proxyInfoD2 != null) {
                            arrayList5.add(proxyInfoD2);
                        }
                    }
                    return ru.k0(40, arrayList5);
                } catch (Exception unused3) {
                    return zk0Var;
                }
            default:
                cj0.I(obj);
                try {
                    ResponseBody responseBody4 = new RealCall(ox0Var.d, ox0.f("https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt")).c().n;
                    if (responseBody4 == null || (strN4 = responseBody4.n()) == null) {
                        return zk0Var;
                    }
                    List listK2 = z13.k0(strN4);
                    ArrayList arrayList6 = new ArrayList();
                    for (Object obj6 : listK2) {
                        if (!z13.g0((String) obj6)) {
                            arrayList6.add(obj6);
                        }
                    }
                    ArrayList arrayList7 = new ArrayList();
                    int size3 = arrayList6.size();
                    while (i < size3) {
                        Object obj7 = arrayList6.get(i);
                        i++;
                        ProxyInfo proxyInfoD3 = ox0.d((String) obj7);
                        if (proxyInfoD3 != null) {
                            arrayList7.add(proxyInfoD3);
                        }
                    }
                    return ru.k0(30, arrayList7);
                } catch (Exception unused4) {
                    return zk0Var;
                }
        }
    }
}
