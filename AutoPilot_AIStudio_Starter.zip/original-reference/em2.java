package defpackage;

import com.autopilot.app.domain.model.DeviceFingerprint;
import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-9e9d01703a38bd5606c48ed47f0b7de32f47adb46ac9f9fd37ba7f9d580026b3 */
/* JADX INFO: loaded from: classes.dex */
public final class em2 {
    public final jw2 a;
    public final Map b;

    static {
        int i = jw2.a;
    }

    public em2(jw2 jw2Var) {
        jw2Var.getClass();
        this.a = jw2Var;
        this.b = rp1.Z(new t42("US", "America/New_York"), new t42("GB", "Europe/London"), new t42("UK", "Europe/London"), new t42("CA", "America/Toronto"), new t42("DE", "Europe/Berlin"), new t42("FR", "Europe/Paris"), new t42("IN", "Asia/Kolkata"), new t42("AU", "Australia/Sydney"), new t42("JP", "Asia/Tokyo"), new t42("SG", "Asia/Singapore"), new t42("BR", "America/Sao_Paulo"), new t42("NL", "Europe/Amsterdam"), new t42("RU", "Europe/Moscow"), new t42("CN", "Asia/Shanghai"), new t42("KR", "Asia/Seoul"), new t42("MY", "Asia/Kuala_Lumpur"), new t42("ID", "Asia/Jakarta"), new t42("PH", "Asia/Manila"), new t42("VN", "Asia/Ho_Chi_Minh"), new t42("TH", "Asia/Bangkok"));
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object a(DeviceFingerprint deviceFingerprint, u20 u20Var) {
        xl2 xl2Var;
        if (u20Var instanceof xl2) {
            xl2Var = (xl2) u20Var;
            int i = xl2Var.c;
            if ((i & Integer.MIN_VALUE) != 0) {
                xl2Var.c = i - Integer.MIN_VALUE;
            } else {
                xl2Var = new xl2(this, u20Var);
            }
        } else {
            xl2Var = new xl2(this, u20Var);
        }
        Object obj = xl2Var.a;
        int i2 = xl2Var.c;
        if (i2 == 0) {
            cj0.I(obj);
            String strK = dr1.k("settings put secure android_id ", deviceFingerprint.getAndroidId());
            xl2Var.c = 1;
            Object objB = jw2.b(this.a, strK, true, xl2Var, 4);
            c40 c40Var = c40.a;
            if (objB == c40Var) {
                return c40Var;
            }
        } else {
            if (i2 != 1) {
                g.n("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            cj0.I(obj);
        }
        return lh3.a;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object b(DeviceFingerprint deviceFingerprint, u20 u20Var) {
        yl2 yl2Var;
        Iterator it;
        if (u20Var instanceof yl2) {
            yl2Var = (yl2) u20Var;
            int i = yl2Var.d;
            if ((i & Integer.MIN_VALUE) != 0) {
                yl2Var.d = i - Integer.MIN_VALUE;
            } else {
                yl2Var = new yl2(this, u20Var);
            }
        } else {
            yl2Var = new yl2(this, u20Var);
        }
        Object obj = yl2Var.b;
        int i2 = yl2Var.d;
        if (i2 == 0) {
            cj0.I(obj);
            it = rp1.Z(new t42("ro.product.model", deviceFingerprint.getBuildModel()), new t42("ro.product.manufacturer", deviceFingerprint.getBuildManufacturer()), new t42("ro.build.fingerprint", deviceFingerprint.getBuildFingerprint()), new t42("ro.product.device", deviceFingerprint.getBuildDevice()), new t42("ro.product.board", deviceFingerprint.getBuildBoard()), new t42("ro.product.brand", deviceFingerprint.getBuildBrand()), new t42("ro.product.name", deviceFingerprint.getBuildProduct()), new t42("ro.serialno", deviceFingerprint.getSerialNumber())).entrySet().iterator();
        } else {
            if (i2 != 1) {
                g.n("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            it = yl2Var.a;
            cj0.I(obj);
        }
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            String strL = dr1.l("resetprop ", (String) entry.getKey(), " \"", (String) entry.getValue(), "\"");
            yl2Var.a = it;
            yl2Var.d = 1;
            Object objB = jw2.b(this.a, strL, true, yl2Var, 4);
            c40 c40Var = c40.a;
            if (objB == c40Var) {
                return c40Var;
            }
        }
        return lh3.a;
    }

    /* JADX WARN: Code duplicated, block: B:34:0x0076 A[Catch: all -> 0x0086, PHI: r8 r9
      0x0076: PHI (r8v4 'this' em2) = (r8v3 'this' em2), (r8v7 'this' em2) binds: [B:33:0x0074, B:19:0x003b] A[DONT_GENERATE, DONT_INLINE]
      0x0076: PHI (r9v4 com.autopilot.app.domain.model.DeviceFingerprint) = (r9v3 com.autopilot.app.domain.model.DeviceFingerprint), (r9v7 com.autopilot.app.domain.model.DeviceFingerprint) binds: [B:33:0x0074, B:19:0x003b] A[DONT_GENERATE, DONT_INLINE], TryCatch #0 {all -> 0x0086, blocks: (B:14:0x002d, B:37:0x0083, B:19:0x003b, B:34:0x0076, B:22:0x0043, B:32:0x006a, B:25:0x004b, B:30:0x005e, B:28:0x0052), top: B:42:0x0023 }] */
    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x0080, code lost:
    
        if (r10 == r7) goto L36;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object c(com.autopilot.app.domain.model.DeviceFingerprint r9, defpackage.u20 r10) {
        /*
            r8 = this;
            boolean r0 = r10 instanceof defpackage.zl2
            if (r0 == 0) goto L13
            r0 = r10
            zl2 r0 = (defpackage.zl2) r0
            int r1 = r0.e
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.e = r1
            goto L18
        L13:
            zl2 r0 = new zl2
            r0.<init>(r8, r10)
        L18:
            java.lang.Object r10 = r0.c
            int r1 = r0.e
            r2 = 0
            r3 = 4
            r4 = 3
            r5 = 2
            r6 = 1
            c40 r7 = defpackage.c40.a
            if (r1 == 0) goto L4f
            if (r1 == r6) goto L47
            if (r1 == r5) goto L3f
            if (r1 == r4) goto L37
            if (r1 != r3) goto L31
            defpackage.cj0.I(r10)     // Catch: java.lang.Throwable -> L86
            goto L83
        L31:
            java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
            defpackage.g.n(r8)
            return r2
        L37:
            em2 r8 = r0.b
            com.autopilot.app.domain.model.DeviceFingerprint r9 = r0.a
            defpackage.cj0.I(r10)     // Catch: java.lang.Throwable -> L86
            goto L76
        L3f:
            em2 r8 = r0.b
            com.autopilot.app.domain.model.DeviceFingerprint r9 = r0.a
            defpackage.cj0.I(r10)     // Catch: java.lang.Throwable -> L86
            goto L6a
        L47:
            em2 r8 = r0.b
            com.autopilot.app.domain.model.DeviceFingerprint r9 = r0.a
            defpackage.cj0.I(r10)     // Catch: java.lang.Throwable -> L86
            goto L5e
        L4f:
            defpackage.cj0.I(r10)
            r0.a = r9     // Catch: java.lang.Throwable -> L86
            r0.b = r8     // Catch: java.lang.Throwable -> L86
            r0.e = r6     // Catch: java.lang.Throwable -> L86
            java.lang.Object r10 = r8.b(r9, r0)     // Catch: java.lang.Throwable -> L86
            if (r10 == r7) goto L82
        L5e:
            r0.a = r9     // Catch: java.lang.Throwable -> L86
            r0.b = r8     // Catch: java.lang.Throwable -> L86
            r0.e = r5     // Catch: java.lang.Throwable -> L86
            java.lang.Object r10 = r8.a(r9, r0)     // Catch: java.lang.Throwable -> L86
            if (r10 == r7) goto L82
        L6a:
            r0.a = r9     // Catch: java.lang.Throwable -> L86
            r0.b = r8     // Catch: java.lang.Throwable -> L86
            r0.e = r4     // Catch: java.lang.Throwable -> L86
            java.lang.Object r10 = r8.e(r9, r0)     // Catch: java.lang.Throwable -> L86
            if (r10 == r7) goto L82
        L76:
            r0.a = r2     // Catch: java.lang.Throwable -> L86
            r0.b = r2     // Catch: java.lang.Throwable -> L86
            r0.e = r3     // Catch: java.lang.Throwable -> L86
            java.lang.Object r10 = r8.g(r9, r0)     // Catch: java.lang.Throwable -> L86
            if (r10 != r7) goto L83
        L82:
            return r7
        L83:
            wl2 r10 = (defpackage.wl2) r10     // Catch: java.lang.Throwable -> L86
            return r10
        L86:
            r8 = move-exception
            ok2 r9 = new ok2
            r9.<init>(r8)
            return r9
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.em2.c(com.autopilot.app.domain.model.DeviceFingerprint, u20):java.lang.Object");
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0019  */
    public final Serializable d(String str, u20 u20Var) {
        am2 am2Var;
        String str2;
        if (u20Var instanceof am2) {
            am2Var = (am2) u20Var;
            int i = am2Var.d;
            if ((i & Integer.MIN_VALUE) != 0) {
                am2Var.d = i - Integer.MIN_VALUE;
            } else {
                am2Var = new am2(this, u20Var);
            }
        } else {
            am2Var = new am2(this, u20Var);
        }
        Object obj = am2Var.b;
        int i2 = am2Var.d;
        try {
            if (i2 == 0) {
                cj0.I(obj);
                Map map = this.b;
                String upperCase = str.toUpperCase(Locale.ROOT);
                upperCase.getClass();
                String str3 = (String) map.get(upperCase);
                if (str3 == null) {
                    return "Timezone mapping not found for ".concat(str);
                }
                am2Var.a = str3;
                am2Var.d = 1;
                Object objB = jw2.b(this.a, "service call alarm 3 s16 \"" + str3 + "\"", true, am2Var, 4);
                c40 c40Var = c40.a;
                if (objB == c40Var) {
                    return c40Var;
                }
                obj = objB;
                str2 = str3;
            } else {
                if (i2 != 1) {
                    g.n("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                str2 = am2Var.a;
                cj0.I(obj);
            }
            kw2 kw2Var = (kw2) obj;
            if (kw2Var.a()) {
                return str2;
            }
            throw new Exception("Failed to set timezone via root: " + kw2Var.b);
        } catch (Throwable th) {
            return new ok2(th);
        }
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object e(DeviceFingerprint deviceFingerprint, u20 u20Var) {
        bm2 bm2Var;
        if (u20Var instanceof bm2) {
            bm2Var = (bm2) u20Var;
            int i = bm2Var.c;
            if ((i & Integer.MIN_VALUE) != 0) {
                bm2Var.c = i - Integer.MIN_VALUE;
            } else {
                bm2Var = new bm2(this, u20Var);
            }
        } else {
            bm2Var = new bm2(this, u20Var);
        }
        Object obj = bm2Var.a;
        int i2 = bm2Var.c;
        if (i2 == 0) {
            cj0.I(obj);
            List listB = su.B("ip link set wlan0 down", dr1.k("ip link set wlan0 address ", deviceFingerprint.getMacAddress()), "ip link set wlan0 up");
            bm2Var.c = 1;
            int i3 = jw2.a;
            w14 w14Var = ji0.b;
            long jC0 = mi0.c0(30);
            jw2 jw2Var = this.a;
            jw2Var.getClass();
            oa0 oa0Var = se0.a;
            Object objR = q6.R(da0.c, new hw2(listB, jw2Var, jC0, null), bm2Var);
            c40 c40Var = c40.a;
            if (objR == c40Var) {
                return c40Var;
            }
        } else {
            if (i2 != 1) {
                g.n("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            cj0.I(obj);
        }
        return lh3.a;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object f(String str, u20 u20Var) {
        cm2 cm2Var;
        if (u20Var instanceof cm2) {
            cm2Var = (cm2) u20Var;
            int i = cm2Var.c;
            if ((i & Integer.MIN_VALUE) != 0) {
                cm2Var.c = i - Integer.MIN_VALUE;
            } else {
                cm2Var = new cm2(this, u20Var);
            }
        } else {
            cm2Var = new cm2(this, u20Var);
        }
        Object obj = cm2Var.a;
        int i2 = cm2Var.c;
        lh3 lh3Var = lh3.a;
        if (i2 != 0) {
            if (i2 == 1) {
                cj0.I(obj);
                return lh3Var;
            }
            g.n("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        cj0.I(obj);
        if (str.length() > 0) {
            String strM = y22.m("service call alarm 3 s16 \"", str, "\"");
            cm2Var.c = 1;
            Object objB = jw2.b(this.a, strM, true, cm2Var, 4);
            c40 c40Var = c40.a;
            if (objB == c40Var) {
                return c40Var;
            }
        }
        return lh3Var;
    }

    /* JADX WARN: Code duplicated, block: B:26:0x0083  */
    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object g(DeviceFingerprint deviceFingerprint, u20 u20Var) {
        dm2 dm2Var;
        DeviceFingerprint deviceFingerprint2;
        kw2 kw2Var;
        kw2 kw2Var2;
        Object objB;
        kw2 kw2Var3;
        DeviceFingerprint deviceFingerprint3;
        if (u20Var instanceof dm2) {
            dm2Var = (dm2) u20Var;
            int i = dm2Var.f;
            if ((i & Integer.MIN_VALUE) != 0) {
                dm2Var.f = i - Integer.MIN_VALUE;
            } else {
                dm2Var = new dm2(this, u20Var);
            }
        } else {
            dm2Var = new dm2(this, u20Var);
        }
        Object objB2 = dm2Var.d;
        int i2 = dm2Var.f;
        jw2 jw2Var = this.a;
        c40 c40Var = c40.a;
        if (i2 == 0) {
            cj0.I(objB2);
            dm2Var.a = deviceFingerprint;
            dm2Var.f = 1;
            objB2 = jw2.b(jw2Var, "getprop ro.product.model", false, dm2Var, 6);
            if (objB2 != c40Var) {
            }
            return c40Var;
        }
        if (i2 == 1) {
            deviceFingerprint = dm2Var.a;
            cj0.I(objB2);
        } else {
            if (i2 == 2) {
                kw2Var = dm2Var.b;
                deviceFingerprint2 = dm2Var.a;
                cj0.I(objB2);
                kw2Var2 = (kw2) objB2;
                dm2Var.a = deviceFingerprint2;
                dm2Var.b = kw2Var;
                dm2Var.c = kw2Var2;
                dm2Var.f = 3;
                objB = jw2.b(jw2Var, "settings get secure android_id", true, dm2Var, 4);
                if (objB != c40Var) {
                    objB2 = objB;
                    kw2Var3 = kw2Var2;
                    deviceFingerprint3 = deviceFingerprint2;
                }
                return c40Var;
            }
            if (i2 != 3) {
                g.n("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            kw2Var3 = dm2Var.c;
            kw2Var = dm2Var.b;
            deviceFingerprint3 = dm2Var.a;
            cj0.I(objB2);
        }
        return new wl2(rr3.l(z13.A0(kw2Var.b).toString(), deviceFingerprint3.getBuildModel()), rr3.l(z13.A0(kw2Var3.b).toString(), deviceFingerprint3.getBuildManufacturer()), rr3.l(z13.A0(((kw2) objB2).b).toString(), deviceFingerprint3.getAndroidId()));
        kw2 kw2Var4 = (kw2) objB2;
        dm2Var.a = deviceFingerprint;
        dm2Var.b = kw2Var4;
        dm2Var.f = 2;
        Object objB3 = jw2.b(jw2Var, "getprop ro.product.manufacturer", false, dm2Var, 6);
        if (objB3 != c40Var) {
            deviceFingerprint2 = deviceFingerprint;
            kw2Var = kw2Var4;
            objB2 = objB3;
            kw2Var2 = (kw2) objB2;
            dm2Var.a = deviceFingerprint2;
            dm2Var.b = kw2Var;
            dm2Var.c = kw2Var2;
            dm2Var.f = 3;
            objB = jw2.b(jw2Var, "settings get secure android_id", true, dm2Var, 4);
            if (objB != c40Var) {
                objB2 = objB;
                kw2Var3 = kw2Var2;
                deviceFingerprint3 = deviceFingerprint2;
                return new wl2(rr3.l(z13.A0(kw2Var.b).toString(), deviceFingerprint3.getBuildModel()), rr3.l(z13.A0(kw2Var3.b).toString(), deviceFingerprint3.getBuildManufacturer()), rr3.l(z13.A0(((kw2) objB2).b).toString(), deviceFingerprint3.getAndroidId()));
            }
        }
        return c40Var;
    }
}
