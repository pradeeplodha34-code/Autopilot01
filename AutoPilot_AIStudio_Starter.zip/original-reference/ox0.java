package defpackage;

import com.autopilot.app.domain.model.ProxyCountryStats;
import com.autopilot.app.domain.model.ProxyInfo;
import com.autopilot.app.domain.model.ProxyProtocol;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.internal._UtilJvmKt;

/* JADX INFO: compiled from: r8-map-id-9e9d01703a38bd5606c48ed47f0b7de32f47adb46ac9f9fd37ba7f9d580026b3 */
/* JADX INFO: loaded from: classes.dex */
public final class ox0 {
    public final su2 a;
    public final s20 b;
    public final ta1 c;
    public final OkHttpClient d;
    public final u03 e;
    public final tg2 f;
    public final u03 g;
    public final tg2 h;
    public final u03 i;
    public final tg2 j;
    public final u03 k;
    public final tg2 l;
    public final u03 m;
    public final tg2 n;
    public final u03 o;
    public final tg2 p;
    public final u03 q;
    public final tg2 r;
    public j03 s;
    public final xs2 t;
    public final Map u;

    public ox0(su2 su2Var) {
        this.a = su2Var;
        c33 c33VarF = hl0.f();
        oa0 oa0Var = se0.a;
        this.b = rr3.c(m3.F(c33VarF, da0.c));
        this.c = pb1.Json$default(null, new hp((byte) 29), 1, null);
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        TimeUnit timeUnit = TimeUnit.SECONDS;
        timeUnit.getClass();
        builder.n = _UtilJvmKt.b(6L, timeUnit);
        builder.o = _UtilJvmKt.b(6L, timeUnit);
        this.d = new OkHttpClient(builder);
        zk0 zk0Var = zk0.a;
        u03 u03VarA = v03.a(zk0Var);
        this.e = u03VarA;
        this.f = pi0.h(u03VarA);
        u03 u03VarA2 = v03.a(null);
        this.g = u03VarA2;
        this.h = pi0.h(u03VarA2);
        u03 u03VarA3 = v03.a(zk0Var);
        this.i = u03VarA3;
        this.j = pi0.h(u03VarA3);
        u03 u03VarA4 = v03.a(Boolean.FALSE);
        this.k = u03VarA4;
        this.l = pi0.h(u03VarA4);
        u03 u03VarA5 = v03.a(null);
        this.m = u03VarA5;
        this.n = pi0.h(u03VarA5);
        u03 u03VarA6 = v03.a(0L);
        this.o = u03VarA6;
        this.p = pi0.h(u03VarA6);
        u03 u03VarA7 = v03.a(null);
        this.q = u03VarA7;
        this.r = pi0.h(u03VarA7);
        int i = ys2.a;
        this.t = new xs2(20);
        this.u = rp1.Z(new t42("US", "United States"), new t42("UK", "United Kingdom"), new t42("GB", "United Kingdom"), new t42("CA", "Canada"), new t42("DE", "Germany"), new t42("FR", "France"), new t42("IN", "India"), new t42("AU", "Australia"), new t42("JP", "Japan"), new t42("SG", "Singapore"), new t42("BR", "Brazil"), new t42("NL", "Netherlands"), new t42("RU", "Russia"), new t42("CN", "China"), new t42("KR", "South Korea"), new t42("ID", "Indonesia"), new t42("MY", "Malaysia"), new t42("PH", "Philippines"), new t42("VN", "Vietnam"), new t42("TH", "Thailand"), new t42("TR", "Turkey"), new t42("UA", "Ukraine"), new t42("PL", "Poland"), new t42("ES", "Spain"), new t42("IT", "Italy"), new t42("MX", "Mexico"), new t42("AR", "Argentina"), new t42("BD", "Bangladesh"), new t42("PK", "Pakistan"), new t42("VN", "Vietnam"), new t42("EG", "Egypt"), new t42("ZA", "South Africa"), new t42("NG", "Nigeria"), new t42("AE", "UAE"), new t42("SA", "Saudi Arabia"), new t42("HK", "Hong Kong"), new t42("TW", "Taiwan"), new t42("IR", "Iran"), new t42("IQ", "Iraq"), new t42("CO", "Colombia"), new t42("EC", "Ecuador"), new t42("PE", "Peru"), new t42("CL", "Chile"), new t42("CZ", "Czechia"), new t42("RO", "Romania"), new t42("HU", "Hungary"), new t42("BG", "Bulgaria"), new t42("SK", "Slovakia"), new t42("AT", "Austria"), new t42("CH", "Switzerland"), new t42("SE", "Sweden"), new t42("NO", "Norway"), new t42("DK", "Denmark"), new t42("FI", "Finland"), new t42("IE", "Ireland"), new t42("PT", "Portugal"), new t42("BE", "Belgium"), new t42("GR", "Greece"), new t42("IL", "Israel"), new t42("KZ", "Kazakhstan"), new t42("UZ", "Uzbekistan"), new t42("NP", "Nepal"), new t42("LK", "Sri Lanka"));
    }

    public static ProxyInfo d(String str) {
        Integer numW;
        int iIntValue;
        ProxyProtocol proxyProtocol;
        List listR0 = z13.r0(z13.o0(z13.o0(z13.o0(z13.o0(z13.A0(str).toString(), "http://"), "https://"), "socks4://"), "socks5://"), new String[]{":"});
        if (listR0.size() != 2 || (numW = g23.W((String) listR0.get(1))) == null || 1 > (iIntValue = numW.intValue()) || iIntValue >= 65536 || z13.g0((CharSequence) listR0.get(0))) {
            return null;
        }
        if (g23.U(str, "socks5", false)) {
            proxyProtocol = ProxyProtocol.SOCKS5;
        } else if (g23.U(str, "socks4", false)) {
            proxyProtocol = ProxyProtocol.SOCKS4;
        } else {
            proxyProtocol = g23.U(str, "https", false) ? ProxyProtocol.HTTPS : ProxyProtocol.HTTP;
        }
        return new ProxyInfo((String) listR0.get(0), iIntValue, proxyProtocol, null, 0L, false, 0L, 0, 248, null);
    }

    public static Request f(String str) {
        Request.Builder builder = new Request.Builder();
        builder.d(str);
        builder.b("User-Agent", "Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.7444.68 Mobile Safari/537.36");
        builder.b("Accept", "*/*");
        return new Request(builder);
    }

    /* JADX WARN: Code duplicated, block: B:8:0x0018  */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00f2, code lost:
    
        if (r0 == r13) goto L36;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object a(defpackage.u20 r18) {
        /*
            Method dump skipped, instruction units count: 374
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ox0.a(u20):java.lang.Object");
    }

    /* JADX WARN: Code duplicated, block: B:19:0x0049 A[DONT_INVERT, PHI: r1
      0x0049: PHI (r1v9 int) = (r1v1 int), (r1v8 int), (r1v11 int) binds: [B:18:0x0045, B:60:0x011b, B:13:0x002c] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:20:0x004b  */
    /* JADX WARN: Code duplicated, block: B:23:0x0060  */
    /* JADX WARN: Code duplicated, block: B:28:0x0077  */
    /* JADX WARN: Code duplicated, block: B:30:0x0083 A[PHI: r1
      0x0083: PHI (r1v7 int) = (r1v9 int), (r1v9 int), (r1v10 int) binds: [B:27:0x0075, B:29:0x0081, B:17:0x003f] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:33:0x0098  */
    /* JADX WARN: Code duplicated, block: B:38:0x00af  */
    /* JADX WARN: Code duplicated, block: B:40:0x00bf  */
    /* JADX WARN: Code duplicated, block: B:43:0x00c6  */
    /* JADX WARN: Code duplicated, block: B:46:0x00cd  */
    /* JADX WARN: Code duplicated, block: B:48:0x00d9  */
    /* JADX WARN: Code duplicated, block: B:51:0x00f0  */
    /* JADX WARN: Code duplicated, block: B:54:0x00f7  */
    /* JADX WARN: Code duplicated, block: B:56:0x0100  */
    /* JADX WARN: Code duplicated, block: B:59:0x010d  */
    /* JADX WARN: Code duplicated, block: B:64:0x006d A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:66:0x005a A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:69:0x00a5 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:71:0x0092 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:73:0x00ec A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:76:0x00d7 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:60:0x011b -> B:19:0x0049). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    public final java.lang.Object b(defpackage.u20 r12) {
        /*
            Method dump skipped, instruction units count: 287
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ox0.b(u20):java.lang.Object");
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0017  */
    public final Object c(ProxyInfo proxyInfo, int i, u20 u20Var) {
        lx0 lx0Var;
        u03 u03Var;
        Object value;
        ArrayList arrayList;
        ProxyInfo proxyInfo2;
        if (u20Var instanceof lx0) {
            lx0Var = (lx0) u20Var;
            int i2 = lx0Var.c;
            if ((i2 & Integer.MIN_VALUE) != 0) {
                lx0Var.c = i2 - Integer.MIN_VALUE;
            } else {
                lx0Var = new lx0(this, u20Var);
            }
        } else {
            lx0Var = new lx0(this, u20Var);
        }
        Object obj = lx0Var.a;
        int i3 = lx0Var.c;
        lh3 lh3Var = lh3.a;
        if (i3 != 0) {
            if (i3 == 1) {
                cj0.I(obj);
                return lh3Var;
            }
            g.n("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        cj0.I(obj);
        boolean z = false;
        do {
            u03Var = this.e;
            value = u03Var.getValue();
            List<ProxyInfo> list = (List) value;
            arrayList = new ArrayList(su.m(list, 10));
            for (ProxyInfo proxyInfoCopy$default : list) {
                if (rr3.l(proxyInfoCopy$default.getHost(), proxyInfo.getHost()) && proxyInfoCopy$default.getPort() == proxyInfo.getPort()) {
                    int failureCount = proxyInfoCopy$default.getFailureCount() + 1;
                    if (failureCount >= i) {
                        proxyInfoCopy$default = ProxyInfo.copy$default(proxyInfoCopy$default, null, 0, null, null, 0L, false, 0L, failureCount, 95, null);
                        z = true;
                    } else {
                        proxyInfoCopy$default = ProxyInfo.copy$default(proxyInfoCopy$default, null, 0, null, null, 0L, false, 0L, failureCount, 127, null);
                    }
                }
                arrayList.add(proxyInfoCopy$default);
            }
        } while (!u03Var.i(value, arrayList));
        if (z) {
            e();
        }
        u03 u03Var2 = this.g;
        ProxyInfo proxyInfo3 = (ProxyInfo) u03Var2.getValue();
        if (rr3.l(proxyInfo3 != null ? proxyInfo3.getHost() : null, proxyInfo.getHost()) && (proxyInfo2 = (ProxyInfo) u03Var2.getValue()) != null && proxyInfo2.getPort() == proxyInfo.getPort() && z) {
            lx0Var.c = 1;
            Object objG = g(lx0Var);
            Object obj2 = c40.a;
            if (objG == obj2) {
                return obj2;
            }
        }
        return lh3Var;
    }

    public final void e() {
        Iterable iterable = (Iterable) this.e.getValue();
        ArrayList arrayList = new ArrayList();
        for (Object obj : iterable) {
            if (((ProxyInfo) obj).isAlive()) {
                arrayList.add(obj);
            }
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            Object obj2 = arrayList.get(i);
            i++;
            String upperCase = ((ProxyInfo) obj2).getCountry().toUpperCase(Locale.ROOT);
            upperCase.getClass();
            Object arrayList2 = linkedHashMap.get(upperCase);
            if (arrayList2 == null) {
                arrayList2 = new ArrayList();
                linkedHashMap.put(upperCase, arrayList2);
            }
            ((List) arrayList2).add(obj2);
        }
        ArrayList arrayList3 = new ArrayList(linkedHashMap.size());
        for (Map.Entry entry : linkedHashMap.entrySet()) {
            String str = (String) entry.getKey();
            List list = (List) entry.getValue();
            String str2 = (String) this.u.get(str);
            if (str2 == null) {
                str2 = str;
            }
            arrayList3.add(new ProxyCountryStats(str, str2, list.size()));
        }
        this.i.k(null, ru.j0(arrayList3, new yt0((byte) 11)));
    }

    /* JADX WARN: Code duplicated, block: B:42:0x00bd  */
    /* JADX WARN: Code duplicated, block: B:45:0x00c4  */
    /* JADX WARN: Code duplicated, block: B:47:0x00d0  */
    /* JADX WARN: Code duplicated, block: B:50:0x00e7  */
    /* JADX WARN: Code duplicated, block: B:53:0x00f3  */
    /* JADX WARN: Code duplicated, block: B:54:0x00f5  */
    /* JADX WARN: Code duplicated, block: B:57:0x0107  */
    /* JADX WARN: Code duplicated, block: B:59:0x0110  */
    /* JADX WARN: Code duplicated, block: B:60:0x0112  */
    /* JADX WARN: Code duplicated, block: B:63:0x0124  */
    /* JADX WARN: Code duplicated, block: B:69:0x00e3 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:72:0x00ce A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    /* JADX WARN: Code restructure failed: missing block: B:64:0x012e, code lost:
    
        if (r14 == r7) goto L65;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object g(defpackage.u20 r14) {
        /*
            Method dump skipped, instruction units count: 311
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ox0.g(u20):java.lang.Object");
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object h(ProxyInfo proxyInfo, u20 u20Var) {
        nx0 nx0Var;
        if (u20Var instanceof nx0) {
            nx0Var = (nx0) u20Var;
            int i = nx0Var.c;
            if ((i & Integer.MIN_VALUE) != 0) {
                nx0Var.c = i - Integer.MIN_VALUE;
            } else {
                nx0Var = new nx0(this, u20Var);
            }
        } else {
            nx0Var = new nx0(this, u20Var);
        }
        Object objR = nx0Var.a;
        int i2 = nx0Var.c;
        if (i2 == 0) {
            cj0.I(objR);
            oa0 oa0Var = se0.a;
            da0 da0Var = da0.c;
            jh0 jh0Var = new jh0((t20) null, this, proxyInfo);
            nx0Var.c = 1;
            objR = q6.R(da0Var, jh0Var, nx0Var);
            c40 c40Var = c40.a;
            if (objR == c40Var) {
                return c40Var;
            }
        } else {
            if (i2 != 1) {
                g.n("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            cj0.I(objR);
        }
        return ((pk2) objR).a;
    }
}
