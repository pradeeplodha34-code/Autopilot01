package defpackage;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import com.autopilot.app.domain.model.AutomationConfig;
import com.autopilot.app.domain.model.AutomationEvent;
import com.autopilot.app.domain.model.EngineState;
import com.autopilot.app.domain.model.SessionStatus;
import com.autopilot.app.domain.model.TabRealTimeState;
import com.autopilot.app.domain.model.TabState;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: compiled from: r8-map-id-9e9d01703a38bd5606c48ed47f0b7de32f47adb46ac9f9fd37ba7f9d580026b3 */
/* JADX INFO: loaded from: classes.dex */
public final class ij {
    public final ConcurrentHashMap A;
    public final ConcurrentHashMap B;
    public final ConcurrentHashMap C;
    public final vt2 a;
    public final t53 b;
    public final ox0 c;
    public final jm2 d;
    public final em2 e;
    public final oq1 f;
    public final f3 g;
    public final s20 h;
    public final ConcurrentHashMap i;
    public final u03 j;
    public final tg2 k;
    public final u03 l;
    public final tg2 m;
    public j03 n;
    public j03 o;
    public j03 p;
    public j03 q;
    public j03 r;
    public AutomationConfig s;
    public long t;
    public String u;
    public String v;
    public final AtomicInteger w;
    public long x;
    public List y;
    public final ConcurrentHashMap z;

    public ij(Context context, vt2 vt2Var, t53 t53Var, ox0 ox0Var, jm2 jm2Var, em2 em2Var, oq1 oq1Var, f3 f3Var) {
        context.getClass();
        vt2Var.getClass();
        t53Var.getClass();
        ox0Var.getClass();
        jm2Var.getClass();
        em2Var.getClass();
        oq1Var.getClass();
        this.a = vt2Var;
        this.b = t53Var;
        this.c = ox0Var;
        this.d = jm2Var;
        this.e = em2Var;
        this.f = oq1Var;
        this.g = f3Var;
        this.h = rr3.c(m3.F(hl0.f(), se0.a));
        this.i = new ConcurrentHashMap();
        u03 u03VarA = v03.a(new EngineState(null, null, null, 0, 0, 0, 0, 0L, null, null, false, null, null, false, null, 0, 0L, 131071, null));
        this.j = u03VarA;
        this.k = pi0.h(u03VarA);
        zk0 zk0Var = zk0.a;
        u03 u03VarA2 = v03.a(zk0Var);
        this.l = u03VarA2;
        this.m = pi0.h(u03VarA2);
        this.u = "";
        this.w = new AtomicInteger(0);
        this.y = zk0Var;
        this.z = new ConcurrentHashMap();
        this.A = new ConcurrentHashMap();
        this.B = new ConcurrentHashMap();
        this.C = new ConcurrentHashMap();
    }

    public static int d(AutomationConfig automationConfig) {
        int refreshIntervalSec = automationConfig.getRefreshIntervalSec() / automationConfig.getScrollIntervalSec();
        if (refreshIntervalSec < 1) {
            refreshIntervalSec = 1;
        }
        if (!automationConfig.getRandomizeIntervals()) {
            return refreshIntervalSec;
        }
        int i = refreshIntervalSec - 2;
        if (i < 2) {
            i = 2;
        }
        t71 t71Var = new t71(i, refreshIntervalSec + 2, 1);
        t0 t0Var = jg2.a;
        return pi0.I(t71Var);
    }

    /* JADX WARN: Code duplicated, block: B:29:0x0095 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:30:0x0097 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:31:0x0099  */
    /* JADX WARN: Code duplicated, block: B:33:0x009c  */
    /* JADX WARN: Code duplicated, block: B:34:0x009f  */
    /* JADX WARN: Code duplicated, block: B:36:0x00a3  */
    /* JADX WARN: Code duplicated, block: B:37:0x00a6  */
    /* JADX WARN: Code duplicated, block: B:38:0x00a9  */
    /* JADX WARN: Code duplicated, block: B:41:0x00d3 A[PHI: r1 r4
      0x00d3: PHI (r1v13 com.autopilot.app.domain.model.ProxyInfo) = (r1v9 com.autopilot.app.domain.model.ProxyInfo), (r1v19 com.autopilot.app.domain.model.ProxyInfo) binds: [B:40:0x00d1, B:16:0x0045] A[DONT_GENERATE, DONT_INLINE]
      0x00d3: PHI (r4v5 boolean) = (r4v3 boolean), (r4v8 boolean) binds: [B:40:0x00d1, B:16:0x0045] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:45:0x012e  */
    /* JADX WARN: Code duplicated, block: B:46:0x015a  */
    /* JADX WARN: Code duplicated, block: B:50:0x0198  */
    /* JADX WARN: Code duplicated, block: B:53:0x01a1  */
    /* JADX WARN: Code duplicated, block: B:56:0x01bc  */
    /* JADX WARN: Code duplicated, block: B:7:0x0017  */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0072, code lost:
    
        if (r1 != r3) goto L22;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object a(boolean r36, defpackage.u20 r37) {
        /*
            Method dump skipped, instruction units count: 465
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ij.a(boolean, u20):java.lang.Object");
    }

    /* JADX WARN: Code duplicated, block: B:45:0x00c5 A[Catch: Exception -> 0x01b5, TRY_LEAVE, TryCatch #1 {Exception -> 0x01b5, blocks: (B:58:0x0191, B:60:0x0197, B:19:0x0047, B:43:0x00bc, B:45:0x00c5, B:50:0x00d4, B:52:0x0118, B:53:0x011a, B:51:0x00ef, B:22:0x0052, B:27:0x0068, B:29:0x0070, B:31:0x007b, B:32:0x0085, B:34:0x008b, B:39:0x00a2, B:41:0x00a9, B:25:0x0059), top: B:67:0x002a }] */
    /* JADX WARN: Code duplicated, block: B:51:0x00ef A[Catch: Exception -> 0x01b5, TryCatch #1 {Exception -> 0x01b5, blocks: (B:58:0x0191, B:60:0x0197, B:19:0x0047, B:43:0x00bc, B:45:0x00c5, B:50:0x00d4, B:52:0x0118, B:53:0x011a, B:51:0x00ef, B:22:0x0052, B:27:0x0068, B:29:0x0070, B:31:0x007b, B:32:0x0085, B:34:0x008b, B:39:0x00a2, B:41:0x00a9, B:25:0x0059), top: B:67:0x002a }] */
    /* JADX WARN: Code duplicated, block: B:58:0x0191 A[Catch: Exception -> 0x01b5, PHI: r2
      0x0191: PHI (r2v3 ??) = (r2v2 ??), (r2v10 ??), (r2v11 ??) binds: [B:65:0x0191, B:44:0x00c3, B:66:0x0191] A[DONT_GENERATE, DONT_INLINE], TRY_ENTER, TryCatch #1 {Exception -> 0x01b5, blocks: (B:58:0x0191, B:60:0x0197, B:19:0x0047, B:43:0x00bc, B:45:0x00c5, B:50:0x00d4, B:52:0x0118, B:53:0x011a, B:51:0x00ef, B:22:0x0052, B:27:0x0068, B:29:0x0070, B:31:0x007b, B:32:0x0085, B:34:0x008b, B:39:0x00a2, B:41:0x00a9, B:25:0x0059), top: B:67:0x002a }] */
    /* JADX WARN: Code duplicated, block: B:60:0x0197 A[Catch: Exception -> 0x01b5, TRY_LEAVE, TryCatch #1 {Exception -> 0x01b5, blocks: (B:58:0x0191, B:60:0x0197, B:19:0x0047, B:43:0x00bc, B:45:0x00c5, B:50:0x00d4, B:52:0x0118, B:53:0x011a, B:51:0x00ef, B:22:0x0052, B:27:0x0068, B:29:0x0070, B:31:0x007b, B:32:0x0085, B:34:0x008b, B:39:0x00a2, B:41:0x00a9, B:25:0x0059), top: B:67:0x002a }] */
    /* JADX WARN: Code duplicated, block: B:7:0x0019  */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x018e, code lost:
    
        if (((defpackage.hu2) r7).e(r4, r11, r3) == r10) goto L57;
     */
    /* JADX WARN: Instruction removed from duplicated block: B:51:0x00ef, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:60:0x0197, please report this as an issue */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v0, types: [t53] */
    /* JADX WARN: Type inference failed for: r2v10, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r2v11 */
    /* JADX WARN: Type inference failed for: r2v14 */
    /* JADX WARN: Type inference failed for: r2v15 */
    /* JADX WARN: Type inference failed for: r2v2 */
    /* JADX WARN: Type inference failed for: r2v3, types: [java.lang.Object] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object b(java.lang.String r35, defpackage.u20 r36) {
        /*
            Method dump skipped, instruction units count: 457
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ij.b(java.lang.String, u20):java.lang.Object");
    }

    public final void c(AutomationEvent automationEvent) {
        u03 u03Var;
        Object value;
        ArrayList arrayList;
        do {
            u03Var = this.l;
            value = u03Var.getValue();
            List list = (List) value;
            arrayList = new ArrayList(list.size() + 1);
            arrayList.add(automationEvent);
            arrayList.addAll(list);
            if (arrayList.size() > 100) {
                arrayList.subList(100, arrayList.size()).clear();
            }
        } while (!u03Var.i(value, arrayList));
    }

    /* JADX WARN: Code duplicated, block: B:53:0x0122 A[PHI: r0 r1 r3 r4 r5 r7 r11
      0x0122: PHI (r0v7 ni) = (r0v6 ni), (r0v13 ni) binds: [B:52:0x0120, B:17:0x003f] A[DONT_GENERATE, DONT_INLINE]
      0x0122: PHI (r1v4 com.autopilot.app.domain.model.AutomationConfig) = (r1v3 com.autopilot.app.domain.model.AutomationConfig), (r1v8 com.autopilot.app.domain.model.AutomationConfig) binds: [B:52:0x0120, B:17:0x003f] A[DONT_GENERATE, DONT_INLINE]
      0x0122: PHI (r3v4 java.lang.String) = (r3v3 java.lang.String), (r3v11 java.lang.String) binds: [B:52:0x0120, B:17:0x003f] A[DONT_GENERATE, DONT_INLINE]
      0x0122: PHI (r4v19 ij) = (r4v18 ij), (r4v25 ij) binds: [B:52:0x0120, B:17:0x003f] A[DONT_GENERATE, DONT_INLINE]
      0x0122: PHI (r5v15 java.lang.String) = (r5v14 java.lang.String), (r5v18 java.lang.String) binds: [B:52:0x0120, B:17:0x003f] A[DONT_GENERATE, DONT_INLINE]
      0x0122: PHI (r7v13 c40) = (r7v11 c40), (r7v17 c40) binds: [B:52:0x0120, B:17:0x003f] A[DONT_GENERATE, DONT_INLINE]
      0x0122: PHI (r11v4 java.lang.String) = (r11v3 java.lang.String), (r11v6 java.lang.String) binds: [B:52:0x0120, B:17:0x003f] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:55:0x0131  */
    /* JADX WARN: Code duplicated, block: B:56:0x0136  */
    /* JADX WARN: Code duplicated, block: B:60:0x0148  */
    /* JADX WARN: Code duplicated, block: B:8:0x001c  */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x00d7, code lost:
    
        if (((defpackage.hu2) r4).g(r1, r3, r2, r0) == r7) goto L63;
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x0160, code lost:
    
        if (r4.f(r11, r3, r2, r1, r5, r6) == r7) goto L63;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object e(java.lang.String r26, java.lang.String r27, java.lang.String r28, com.autopilot.app.domain.model.AutomationConfig r29, java.lang.Exception r30, defpackage.u20 r31) {
        /*
            Method dump skipped, instruction units count: 358
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ij.e(java.lang.String, java.lang.String, java.lang.String, com.autopilot.app.domain.model.AutomationConfig, java.lang.Exception, u20):java.lang.Object");
    }

    /* JADX WARN: Code duplicated, block: B:69:0x01d7  */
    /* JADX WARN: Code duplicated, block: B:7:0x0019  */
    /* JADX WARN: Code restructure failed: missing block: B:64:0x0197, code lost:
    
        if (((defpackage.hu2) r5).g(r12, r14, r13, r3) != r11) goto L65;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object f(java.lang.String r39, java.lang.String r40, int r41, com.autopilot.app.domain.model.AutomationConfig r42, java.lang.String r43, defpackage.u20 r44) {
        /*
            Method dump skipped, instruction units count: 585
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ij.f(java.lang.String, java.lang.String, int, com.autopilot.app.domain.model.AutomationConfig, java.lang.String, u20):java.lang.Object");
    }

    public final void g(String str, String str2, String str3, AutomationConfig automationConfig) {
        t53 t53Var = this.b;
        t53Var.getClass();
        str2.getClass();
        w91 w91Var = (w91) t53Var.e.get(str2);
        if (w91Var == null) {
            return;
        }
        ConcurrentHashMap concurrentHashMap = this.i;
        ca1 ca1Var = (ca1) concurrentHashMap.get(str2);
        if (ca1Var != null) {
            ca1Var.cancel(null);
        }
        concurrentHashMap.put(str2, q6.G(this.h, null, null, new qi(automationConfig, this, w91Var, str2, str3, str, null), 3));
    }

    /* JADX WARN: Code duplicated, block: B:19:0x0066 A[PHI: r9 r10 r11 r12 r13
      0x0066: PHI (r9v6 boolean) = (r9v5 boolean), (r9v20 boolean) binds: [B:36:0x00d4, B:18:0x005b] A[DONT_GENERATE, DONT_INLINE]
      0x0066: PHI (r10v6 java.lang.String) = (r10v5 java.lang.String), (r10v22 java.lang.String) binds: [B:36:0x00d4, B:18:0x005b] A[DONT_GENERATE, DONT_INLINE]
      0x0066: PHI (r11v6 ??) = (r11v25 ??), (r11v26 ??) binds: [B:36:0x00d4, B:18:0x005b] A[DONT_GENERATE, DONT_INLINE]
      0x0066: PHI (r12v6 ??) = (r12v25 ??), (r12v26 ??) binds: [B:36:0x00d4, B:18:0x005b] A[DONT_GENERATE, DONT_INLINE]
      0x0066: PHI (r13v10 java.lang.Object) = (r13v9 java.lang.Object), (r13v1 java.lang.Object) binds: [B:36:0x00d4, B:18:0x005b] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:30:0x00a1  */
    /* JADX WARN: Code duplicated, block: B:31:0x00a4  */
    /* JADX WARN: Code duplicated, block: B:34:0x00ba  */
    /* JADX WARN: Code duplicated, block: B:40:0x00e0  */
    /* JADX WARN: Code duplicated, block: B:42:0x00e7 A[Catch: all -> 0x00fa, TRY_ENTER, TRY_LEAVE, TryCatch #0 {all -> 0x00fa, blocks: (B:16:0x0056, B:42:0x00e7), top: B:63:0x0023 }] */
    /* JADX WARN: Code duplicated, block: B:44:0x00fa A[PHI: r1 r9 r10 r11 r12
      0x00fa: PHI (r1v3 ??) = (r1v1 ??), (r1v2 ??), (r1v5 ??) binds: [B:60:0x00fa, B:41:0x00e5, B:62:0x00fa] A[DONT_GENERATE, DONT_INLINE]
      0x00fa: PHI (r9v8 ??) = (r9v2 ??), (r9v7 ??), (r9v10 ??) binds: [B:60:0x00fa, B:41:0x00e5, B:62:0x00fa] A[DONT_GENERATE, DONT_INLINE]
      0x00fa: PHI (r10v8 ??) = (r10v2 ??), (r10v7 ??), (r10v10 ??) binds: [B:60:0x00fa, B:41:0x00e5, B:62:0x00fa] A[DONT_GENERATE, DONT_INLINE]
      0x00fa: PHI (r11v8 java.lang.String) = (r11v2 java.lang.String), (r11v7 java.lang.String), (r11v12 java.lang.String) binds: [B:60:0x00fa, B:41:0x00e5, B:62:0x00fa] A[DONT_GENERATE, DONT_INLINE]
      0x00fa: PHI (r12v8 ??) = (r12v2 ??), (r12v7 ??), (r12v10 ??) binds: [B:60:0x00fa, B:41:0x00e5, B:62:0x00fa] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:46:0x010f  */
    /* JADX WARN: Code duplicated, block: B:49:0x0126  */
    /* JADX WARN: Code duplicated, block: B:51:0x0130 A[DONT_INVERT, PHI: r9 r10 r12
      0x0130: PHI (r9v12 ??) = (r9v27 ??), (r9v14 ??) binds: [B:39:0x00de, B:50:0x0127] A[DONT_GENERATE, DONT_INLINE]
      0x0130: PHI (r10v14 ??) = (r10v28 ??), (r10v18 ??) binds: [B:39:0x00de, B:50:0x0127] A[DONT_GENERATE, DONT_INLINE]
      0x0130: PHI (r12v12 ??) = (r12v20 ??), (r12v13 ??) binds: [B:39:0x00de, B:50:0x0127] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:52:0x0132  */
    /* JADX WARN: Code duplicated, block: B:55:0x0155  */
    /* JADX WARN: Code duplicated, block: B:57:0x0158  */
    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x009d, code lost:
    
        if (r13 != r6) goto L65;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00f8, code lost:
    
        if (r1.a(r0) != r6) goto L62;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v0, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r10v1 */
    /* JADX WARN: Type inference failed for: r10v10 */
    /* JADX WARN: Type inference failed for: r10v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r10v13 */
    /* JADX WARN: Type inference failed for: r10v14, types: [boolean] */
    /* JADX WARN: Type inference failed for: r10v17 */
    /* JADX WARN: Type inference failed for: r10v18 */
    /* JADX WARN: Type inference failed for: r10v19 */
    /* JADX WARN: Type inference failed for: r10v2 */
    /* JADX WARN: Type inference failed for: r10v25 */
    /* JADX WARN: Type inference failed for: r10v27 */
    /* JADX WARN: Type inference failed for: r10v28 */
    /* JADX WARN: Type inference failed for: r10v29 */
    /* JADX WARN: Type inference failed for: r10v3, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r10v30 */
    /* JADX WARN: Type inference failed for: r10v31 */
    /* JADX WARN: Type inference failed for: r10v32 */
    /* JADX WARN: Type inference failed for: r10v7, types: [boolean] */
    /* JADX WARN: Type inference failed for: r10v8, types: [boolean] */
    /* JADX WARN: Type inference failed for: r10v9 */
    /* JADX WARN: Type inference failed for: r11v10 */
    /* JADX WARN: Type inference failed for: r11v11 */
    /* JADX WARN: Type inference failed for: r11v13, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r11v24 */
    /* JADX WARN: Type inference failed for: r11v25 */
    /* JADX WARN: Type inference failed for: r11v26 */
    /* JADX WARN: Type inference failed for: r11v27 */
    /* JADX WARN: Type inference failed for: r11v4 */
    /* JADX WARN: Type inference failed for: r11v5, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r11v6 */
    /* JADX WARN: Type inference failed for: r12v0, types: [boolean] */
    /* JADX WARN: Type inference failed for: r12v1 */
    /* JADX WARN: Type inference failed for: r12v10 */
    /* JADX WARN: Type inference failed for: r12v11, types: [w91] */
    /* JADX WARN: Type inference failed for: r12v12, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r12v13 */
    /* JADX WARN: Type inference failed for: r12v14 */
    /* JADX WARN: Type inference failed for: r12v2 */
    /* JADX WARN: Type inference failed for: r12v20 */
    /* JADX WARN: Type inference failed for: r12v21 */
    /* JADX WARN: Type inference failed for: r12v22 */
    /* JADX WARN: Type inference failed for: r12v23 */
    /* JADX WARN: Type inference failed for: r12v24 */
    /* JADX WARN: Type inference failed for: r12v25 */
    /* JADX WARN: Type inference failed for: r12v26 */
    /* JADX WARN: Type inference failed for: r12v27 */
    /* JADX WARN: Type inference failed for: r12v28 */
    /* JADX WARN: Type inference failed for: r12v29 */
    /* JADX WARN: Type inference failed for: r12v3, types: [boolean] */
    /* JADX WARN: Type inference failed for: r12v4 */
    /* JADX WARN: Type inference failed for: r12v5, types: [w91] */
    /* JADX WARN: Type inference failed for: r12v6 */
    /* JADX WARN: Type inference failed for: r12v7, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r12v8 */
    /* JADX WARN: Type inference failed for: r12v9, types: [w91] */
    /* JADX WARN: Type inference failed for: r13v15, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v0, types: [int] */
    /* JADX WARN: Type inference failed for: r1v1 */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v2, types: [w91] */
    /* JADX WARN: Type inference failed for: r1v3 */
    /* JADX WARN: Type inference failed for: r1v5 */
    /* JADX WARN: Type inference failed for: r1v9 */
    /* JADX WARN: Type inference failed for: r7v0 */
    /* JADX WARN: Type inference failed for: r8v0, types: [ij] */
    /* JADX WARN: Type inference failed for: r9v0, types: [w91] */
    /* JADX WARN: Type inference failed for: r9v1 */
    /* JADX WARN: Type inference failed for: r9v10 */
    /* JADX WARN: Type inference failed for: r9v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r9v14 */
    /* JADX WARN: Type inference failed for: r9v15, types: [boolean] */
    /* JADX WARN: Type inference failed for: r9v16 */
    /* JADX WARN: Type inference failed for: r9v17 */
    /* JADX WARN: Type inference failed for: r9v2 */
    /* JADX WARN: Type inference failed for: r9v26 */
    /* JADX WARN: Type inference failed for: r9v27 */
    /* JADX WARN: Type inference failed for: r9v28 */
    /* JADX WARN: Type inference failed for: r9v29 */
    /* JADX WARN: Type inference failed for: r9v3, types: [w91] */
    /* JADX WARN: Type inference failed for: r9v30 */
    /* JADX WARN: Type inference failed for: r9v31 */
    /* JADX WARN: Type inference failed for: r9v7, types: [boolean] */
    /* JADX WARN: Type inference failed for: r9v8, types: [boolean] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object h(defpackage.w91 r9, java.lang.String r10, java.lang.String r11, boolean r12, defpackage.u20 r13) {
        /*
            Method dump skipped, instruction units count: 374
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ij.h(w91, java.lang.String, java.lang.String, boolean, u20):java.lang.Object");
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0017  */
    public final Object i(u20 u20Var) {
        ui uiVar;
        Object value;
        if (u20Var instanceof ui) {
            uiVar = (ui) u20Var;
            int i = uiVar.c;
            if ((i & Integer.MIN_VALUE) != 0) {
                uiVar.c = i - Integer.MIN_VALUE;
            } else {
                uiVar = new ui(this, u20Var);
            }
        } else {
            uiVar = new ui(this, u20Var);
        }
        Object objP = uiVar.a;
        int i2 = uiVar.c;
        u03 u03Var = this.j;
        if (i2 == 0) {
            cj0.I(objP);
            if (((EngineState) u03Var.getValue()).getProxyActive()) {
                long jCurrentTimeMillis = System.currentTimeMillis();
                if (jCurrentTimeMillis - this.x >= 120000) {
                    this.x = jCurrentTimeMillis;
                    c(new AutomationEvent.Info("Repeated load failures — rotating proxy..."));
                    uiVar.c = 1;
                    objP = p(uiVar);
                    Object obj = c40.a;
                    if (objP == obj) {
                        return obj;
                    }
                }
            }
            return lh3.a;
        }
        if (i2 != 1) {
            g.n("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        cj0.I(objP);
        if (!((Boolean) objP).booleanValue()) {
            c(new AutomationEvent.Info("No healthy proxy found — continuing direct"));
            do {
                value = u03Var.getValue();
            } while (!u03Var.i(value, EngineState.copy$default((EngineState) value, null, null, null, 0, 0, 0, 0, 0L, null, null, false, null, null, false, null, 0, 0L, 130047, null)));
        }
        return lh3.a;
    }

    public final void j() {
        Object value;
        u03 u03Var = this.j;
        if (((EngineState) u03Var.getValue()).getStatus() != SessionStatus.RUNNING) {
            return;
        }
        j03 j03Var = this.q;
        t20 t20Var = null;
        if (j03Var != null) {
            j03Var.cancel(null);
        }
        this.q = null;
        ConcurrentHashMap concurrentHashMap = this.i;
        Collection<ca1> collectionValues = concurrentHashMap.values();
        collectionValues.getClass();
        for (ca1 ca1Var : collectionValues) {
            ca1Var.getClass();
            ca1Var.cancel(null);
        }
        concurrentHashMap.clear();
        String sessionId = ((EngineState) u03Var.getValue()).getSessionId();
        do {
            value = u03Var.getValue();
        } while (!u03Var.i(value, EngineState.copy$default((EngineState) value, null, SessionStatus.PAUSED, null, 0, 0, 0, 0, 0L, "Paused", null, false, null, null, false, null, 0, 0L, 130813, null)));
        c(new AutomationEvent.SessionPaused(sessionId));
        q6.G(this.h, null, null, new o((Object) this, (Object) sessionId, t20Var, (byte) 2), 3);
    }

    /* JADX WARN: Code duplicated, block: B:28:0x00e1  */
    /* JADX WARN: Code duplicated, block: B:31:0x00f1  */
    /* JADX WARN: Code duplicated, block: B:34:0x010f  */
    /* JADX WARN: Code duplicated, block: B:36:0x0113  */
    /* JADX WARN: Code duplicated, block: B:38:0x0157  */
    /* JADX WARN: Code duplicated, block: B:41:0x0166  */
    /* JADX WARN: Code duplicated, block: B:44:0x0196 A[PHI: r1 r4 r6 r7 r9
      0x0196: PHI (r1v10 int) = (r1v8 int), (r1v11 int) binds: [B:43:0x0194, B:18:0x0082] A[DONT_GENERATE, DONT_INLINE]
      0x0196: PHI (r4v14 int) = (r4v12 int), (r4v15 int) binds: [B:43:0x0194, B:18:0x0082] A[DONT_GENERATE, DONT_INLINE]
      0x0196: PHI (r6v5 int) = (r6v3 int), (r6v7 int) binds: [B:43:0x0194, B:18:0x0082] A[DONT_GENERATE, DONT_INLINE]
      0x0196: PHI (r7v6 java.lang.String) = (r7v4 java.lang.String), (r7v8 java.lang.String) binds: [B:43:0x0194, B:18:0x0082] A[DONT_GENERATE, DONT_INLINE]
      0x0196: PHI (r9v8 w91) = (r9v6 w91), (r9v9 w91) binds: [B:43:0x0194, B:18:0x0082] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:46:0x019c  */
    /* JADX WARN: Code duplicated, block: B:48:0x01b3  */
    /* JADX WARN: Code duplicated, block: B:51:0x01d5 A[PHI: r1 r4 r5 r6 r7
      0x01d5: PHI (r1v14 int) = (r1v12 int), (r1v15 int) binds: [B:50:0x01d3, B:16:0x0064] A[DONT_GENERATE, DONT_INLINE]
      0x01d5: PHI (r4v18 int) = (r4v16 int), (r4v19 int) binds: [B:50:0x01d3, B:16:0x0064] A[DONT_GENERATE, DONT_INLINE]
      0x01d5: PHI (r5v4 int) = (r5v2 int), (r5v5 int) binds: [B:50:0x01d3, B:16:0x0064] A[DONT_GENERATE, DONT_INLINE]
      0x01d5: PHI (r6v10 java.lang.String) = (r6v8 java.lang.String), (r6v11 java.lang.String) binds: [B:50:0x01d3, B:16:0x0064] A[DONT_GENERATE, DONT_INLINE]
      0x01d5: PHI (r7v11 w91) = (r7v9 w91), (r7v12 w91) binds: [B:50:0x01d3, B:16:0x0064] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:53:0x01ed A[PHI: r1 r4 r5 r6
      0x01ed: PHI (r1v16 int) = (r1v14 int), (r1v17 int) binds: [B:52:0x01eb, B:15:0x0057] A[DONT_GENERATE, DONT_INLINE]
      0x01ed: PHI (r4v20 int) = (r4v18 int), (r4v21 int) binds: [B:52:0x01eb, B:15:0x0057] A[DONT_GENERATE, DONT_INLINE]
      0x01ed: PHI (r5v6 int) = (r5v4 int), (r5v7 int) binds: [B:52:0x01eb, B:15:0x0057] A[DONT_GENERATE, DONT_INLINE]
      0x01ed: PHI (r6v12 java.lang.String) = (r6v10 java.lang.String), (r6v14 java.lang.String) binds: [B:52:0x01eb, B:15:0x0057] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:56:0x0214  */
    /* JADX WARN: Code duplicated, block: B:58:0x021c  */
    /* JADX WARN: Code duplicated, block: B:60:0x024d  */
    /* JADX WARN: Code duplicated, block: B:64:0x0276  */
    /* JADX WARN: Code duplicated, block: B:67:0x0297 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:7:0x0019  */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x0273, code lost:
    
        if (defpackage.q6.r(r13, r3) == r11) goto L66;
     */
    /* JADX WARN: Instruction removed from duplicated block: B:36:0x0113, please report this as an issue */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:62:0x0273 -> B:13:0x0042). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object k(defpackage.w91 r24, java.lang.String r25, defpackage.u20 r26) {
        /*
            Method dump skipped, instruction units count: 694
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ij.k(w91, java.lang.String, u20):java.lang.Object");
    }

    /* JADX WARN: Code duplicated, block: B:24:0x00f1  */
    /* JADX WARN: Code duplicated, block: B:27:0x0108  */
    /* JADX WARN: Code duplicated, block: B:29:0x0117  */
    /* JADX WARN: Code duplicated, block: B:34:0x0151  */
    /* JADX WARN: Code duplicated, block: B:36:0x0185  */
    /* JADX WARN: Code duplicated, block: B:39:0x01cf  */
    /* JADX WARN: Code duplicated, block: B:42:0x01d5  */
    /* JADX WARN: Code duplicated, block: B:45:0x01e2  */
    /* JADX WARN: Code duplicated, block: B:47:0x0213  */
    /* JADX WARN: Code duplicated, block: B:54:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:55:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:56:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:57:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:58:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:7:0x001b  */
    public final Object l(w91 w91Var, AutomationConfig automationConfig, String str, u20 u20Var) {
        wi wiVar;
        long j;
        w91 w91Var2;
        long j2;
        AutomationConfig automationConfig2;
        int i;
        AtomicInteger atomicInteger;
        long scrollIntervalSec;
        c40 c40Var;
        String str2;
        long j3;
        long j4;
        int i2;
        long jB;
        int i3;
        long j5;
        long j6;
        long jB2;
        long j7;
        long jB3;
        long j8;
        int i4;
        long jB4;
        String str3 = str;
        if (u20Var instanceof wi) {
            wiVar = (wi) u20Var;
            int i5 = wiVar.q;
            if ((i5 & Integer.MIN_VALUE) != 0) {
                wiVar.q = i5 - Integer.MIN_VALUE;
            } else {
                wiVar = new wi(this, u20Var);
            }
        } else {
            wiVar = new wi(this, u20Var);
        }
        Object obj = wiVar.o;
        int i6 = wiVar.q;
        String str4 = "px";
        c40 c40Var2 = c40.a;
        switch (i6) {
            case 0:
                j = 1000;
                cj0.I(obj);
                int iD = d31.d();
                long jB5 = d31.b(500L, 150L, 200L, 1000L);
                y(str3, "Scrolling " + iD + "px");
                wiVar.a = w91Var;
                wiVar.b = automationConfig;
                wiVar.c = str3;
                wiVar.d = iD;
                wiVar.f = jB5;
                wiVar.q = 1;
                if (w91Var.g(iD, jB5, wiVar) == c40Var2) {
                    return c40Var2;
                }
                w91Var2 = w91Var;
                j2 = jB5;
                automationConfig2 = automationConfig;
                i = iD;
                atomicInteger = (AtomicInteger) this.B.get(str3);
                if (atomicInteger != null) {
                    nq3.p(atomicInteger.incrementAndGet());
                }
                c(new AutomationEvent.ScrollPerformed(str3, i, "down"));
                if (automationConfig2.getRandomizeIntervals()) {
                    scrollIntervalSec = d31.b(5000L, 2000L, 2000L, 12000L);
                } else {
                    scrollIntervalSec = ((long) automationConfig2.getScrollIntervalSec()) * j;
                }
                y(str3, y22.l("Reading pause ", scrollIntervalSec / j, "s"));
                c(new AutomationEvent.ReadingPause(str3, scrollIntervalSec));
                wiVar.a = w91Var2;
                wiVar.b = null;
                wiVar.c = str3;
                wiVar.d = i;
                wiVar.f = j2;
                wiVar.n = scrollIntervalSec;
                wiVar.q = 2;
                c40Var = c40Var2;
                if (q6.r(scrollIntervalSec, wiVar) == c40Var) {
                    return c40Var;
                }
                if (d31.a(15)) {
                    t71 t71Var = new t71(2, 5, 1);
                    t0 t0Var = jg2.a;
                    i2 = -(i / pi0.I(t71Var));
                    jB = d31.b(500L, 150L, 200L, 1000L);
                    wiVar.a = null;
                    wiVar.b = null;
                    wiVar.c = str3;
                    wiVar.d = i;
                    wiVar.f = j2;
                    wiVar.n = scrollIntervalSec;
                    wiVar.e = i2;
                    wiVar.q = 3;
                    if (w91Var2.g(i2, jB, wiVar) == c40Var) {
                        return c40Var;
                    }
                    long j9 = j2;
                    i3 = i;
                    j5 = scrollIntervalSec;
                    j6 = j9;
                    str2 = str3;
                    int i7 = -i2;
                    c(new AutomationEvent.ScrollPerformed(str2, i7, "up"));
                    y(str2, "Scrolled back " + i7 + str4);
                    jB2 = d31.b(1500L, 400L, 500L, 4000L);
                    wiVar.a = null;
                    wiVar.b = null;
                    wiVar.c = str2;
                    wiVar.d = i3;
                    wiVar.f = j6;
                    wiVar.n = j5;
                    wiVar.e = i2;
                    wiVar.q = 4;
                    if (q6.r(jB2, wiVar) != c40Var) {
                        return c40Var;
                    }
                    j3 = j5;
                    j7 = j6;
                    j4 = j7;
                    i = i3;
                } else {
                    str2 = str3;
                    j3 = scrollIntervalSec;
                    j4 = j2;
                }
                if (d31.a(5)) {
                    jB3 = d31.b(10000L, 4000L, 4000L, 25000L);
                    y(str2, y22.l("Distraction pause ", jB3 / j, "s"));
                    wiVar.a = null;
                    wiVar.b = null;
                    wiVar.c = null;
                    wiVar.d = i;
                    wiVar.f = j4;
                    wiVar.n = j3;
                    wiVar.q = 5;
                    c40Var = c40Var;
                    if (q6.r(jB3, wiVar) == c40Var) {
                        return c40Var;
                    }
                    j8 = j3;
                    i4 = i;
                    i = i4;
                    j3 = j8;
                }
                jB4 = d31.b(400L, 150L, 150L, 1000L);
                wiVar.a = null;
                wiVar.b = null;
                wiVar.c = null;
                wiVar.d = i;
                wiVar.f = j4;
                wiVar.n = j3;
                wiVar.q = 6;
                if (q6.r(jB4, wiVar) == c40Var) {
                    return c40Var;
                }
                return lh3.a;
            case 1:
                j = 1000;
                long j10 = wiVar.f;
                i = wiVar.d;
                String str5 = wiVar.c;
                automationConfig2 = wiVar.b;
                w91Var2 = wiVar.a;
                cj0.I(obj);
                j2 = j10;
                str3 = str5;
                atomicInteger = (AtomicInteger) this.B.get(str3);
                if (atomicInteger != null) {
                    nq3.p(atomicInteger.incrementAndGet());
                }
                c(new AutomationEvent.ScrollPerformed(str3, i, "down"));
                if (automationConfig2.getRandomizeIntervals()) {
                    scrollIntervalSec = d31.b(5000L, 2000L, 2000L, 12000L);
                } else {
                    scrollIntervalSec = ((long) automationConfig2.getScrollIntervalSec()) * j;
                }
                y(str3, y22.l("Reading pause ", scrollIntervalSec / j, "s"));
                c(new AutomationEvent.ReadingPause(str3, scrollIntervalSec));
                wiVar.a = w91Var2;
                wiVar.b = null;
                wiVar.c = str3;
                wiVar.d = i;
                wiVar.f = j2;
                wiVar.n = scrollIntervalSec;
                wiVar.q = 2;
                c40Var = c40Var2;
                if (q6.r(scrollIntervalSec, wiVar) == c40Var) {
                    return c40Var;
                }
                if (d31.a(15)) {
                    t71 t71Var2 = new t71(2, 5, 1);
                    t0 t0Var2 = jg2.a;
                    i2 = -(i / pi0.I(t71Var2));
                    jB = d31.b(500L, 150L, 200L, 1000L);
                    wiVar.a = null;
                    wiVar.b = null;
                    wiVar.c = str3;
                    wiVar.d = i;
                    wiVar.f = j2;
                    wiVar.n = scrollIntervalSec;
                    wiVar.e = i2;
                    wiVar.q = 3;
                    if (w91Var2.g(i2, jB, wiVar) == c40Var) {
                        return c40Var;
                    }
                    long j11 = j2;
                    i3 = i;
                    j5 = scrollIntervalSec;
                    j6 = j11;
                    str2 = str3;
                    int i8 = -i2;
                    c(new AutomationEvent.ScrollPerformed(str2, i8, "up"));
                    y(str2, "Scrolled back " + i8 + str4);
                    jB2 = d31.b(1500L, 400L, 500L, 4000L);
                    wiVar.a = null;
                    wiVar.b = null;
                    wiVar.c = str2;
                    wiVar.d = i3;
                    wiVar.f = j6;
                    wiVar.n = j5;
                    wiVar.e = i2;
                    wiVar.q = 4;
                    if (q6.r(jB2, wiVar) != c40Var) {
                        return c40Var;
                    }
                    j3 = j5;
                    j7 = j6;
                    j4 = j7;
                    i = i3;
                } else {
                    str2 = str3;
                    j3 = scrollIntervalSec;
                    j4 = j2;
                }
                if (d31.a(5)) {
                    jB3 = d31.b(10000L, 4000L, 4000L, 25000L);
                    y(str2, y22.l("Distraction pause ", jB3 / j, "s"));
                    wiVar.a = null;
                    wiVar.b = null;
                    wiVar.c = null;
                    wiVar.d = i;
                    wiVar.f = j4;
                    wiVar.n = j3;
                    wiVar.q = 5;
                    c40Var = c40Var;
                    if (q6.r(jB3, wiVar) == c40Var) {
                        return c40Var;
                    }
                    j8 = j3;
                    i4 = i;
                    i = i4;
                    j3 = j8;
                }
                jB4 = d31.b(400L, 150L, 150L, 1000L);
                wiVar.a = null;
                wiVar.b = null;
                wiVar.c = null;
                wiVar.d = i;
                wiVar.f = j4;
                wiVar.n = j3;
                wiVar.q = 6;
                if (q6.r(jB4, wiVar) == c40Var) {
                    return c40Var;
                }
                return lh3.a;
            case 2:
                long j12 = wiVar.n;
                long j13 = wiVar.f;
                i = wiVar.d;
                j = 1000;
                String str6 = wiVar.c;
                w91 w91Var3 = wiVar.a;
                cj0.I(obj);
                str4 = "px";
                j2 = j13;
                w91Var2 = w91Var3;
                scrollIntervalSec = j12;
                c40Var = c40Var2;
                str3 = str6;
                if (d31.a(15)) {
                    t71 t71Var3 = new t71(2, 5, 1);
                    t0 t0Var3 = jg2.a;
                    i2 = -(i / pi0.I(t71Var3));
                    jB = d31.b(500L, 150L, 200L, 1000L);
                    wiVar.a = null;
                    wiVar.b = null;
                    wiVar.c = str3;
                    wiVar.d = i;
                    wiVar.f = j2;
                    wiVar.n = scrollIntervalSec;
                    wiVar.e = i2;
                    wiVar.q = 3;
                    if (w91Var2.g(i2, jB, wiVar) == c40Var) {
                        return c40Var;
                    }
                    long j14 = j2;
                    i3 = i;
                    j5 = scrollIntervalSec;
                    j6 = j14;
                    str2 = str3;
                    int i9 = -i2;
                    c(new AutomationEvent.ScrollPerformed(str2, i9, "up"));
                    y(str2, "Scrolled back " + i9 + str4);
                    jB2 = d31.b(1500L, 400L, 500L, 4000L);
                    wiVar.a = null;
                    wiVar.b = null;
                    wiVar.c = str2;
                    wiVar.d = i3;
                    wiVar.f = j6;
                    wiVar.n = j5;
                    wiVar.e = i2;
                    wiVar.q = 4;
                    if (q6.r(jB2, wiVar) != c40Var) {
                        return c40Var;
                    }
                    j3 = j5;
                    j7 = j6;
                    j4 = j7;
                    i = i3;
                } else {
                    str2 = str3;
                    j3 = scrollIntervalSec;
                    j4 = j2;
                }
                if (d31.a(5)) {
                    jB3 = d31.b(10000L, 4000L, 4000L, 25000L);
                    y(str2, y22.l("Distraction pause ", jB3 / j, "s"));
                    wiVar.a = null;
                    wiVar.b = null;
                    wiVar.c = null;
                    wiVar.d = i;
                    wiVar.f = j4;
                    wiVar.n = j3;
                    wiVar.q = 5;
                    c40Var = c40Var;
                    if (q6.r(jB3, wiVar) == c40Var) {
                        return c40Var;
                    }
                    j8 = j3;
                    i4 = i;
                    i = i4;
                    j3 = j8;
                }
                jB4 = d31.b(400L, 150L, 150L, 1000L);
                wiVar.a = null;
                wiVar.b = null;
                wiVar.c = null;
                wiVar.d = i;
                wiVar.f = j4;
                wiVar.n = j3;
                wiVar.q = 6;
                if (q6.r(jB4, wiVar) == c40Var) {
                    return c40Var;
                }
                return lh3.a;
            case 3:
                int i10 = wiVar.e;
                j5 = wiVar.n;
                j6 = wiVar.f;
                int i11 = wiVar.d;
                String str7 = wiVar.c;
                cj0.I(obj);
                i2 = i10;
                str4 = "px";
                c40Var = c40Var2;
                j = 1000;
                str2 = str7;
                i3 = i11;
                int i12 = -i2;
                c(new AutomationEvent.ScrollPerformed(str2, i12, "up"));
                y(str2, "Scrolled back " + i12 + str4);
                jB2 = d31.b(1500L, 400L, 500L, 4000L);
                wiVar.a = null;
                wiVar.b = null;
                wiVar.c = str2;
                wiVar.d = i3;
                wiVar.f = j6;
                wiVar.n = j5;
                wiVar.e = i2;
                wiVar.q = 4;
                if (q6.r(jB2, wiVar) != c40Var) {
                    return c40Var;
                }
                j3 = j5;
                j7 = j6;
                j4 = j7;
                i = i3;
                if (d31.a(5)) {
                    jB3 = d31.b(10000L, 4000L, 4000L, 25000L);
                    y(str2, y22.l("Distraction pause ", jB3 / j, "s"));
                    wiVar.a = null;
                    wiVar.b = null;
                    wiVar.c = null;
                    wiVar.d = i;
                    wiVar.f = j4;
                    wiVar.n = j3;
                    wiVar.q = 5;
                    c40Var = c40Var;
                    if (q6.r(jB3, wiVar) == c40Var) {
                        return c40Var;
                    }
                    j8 = j3;
                    i4 = i;
                    i = i4;
                    j3 = j8;
                }
                jB4 = d31.b(400L, 150L, 150L, 1000L);
                wiVar.a = null;
                wiVar.b = null;
                wiVar.c = null;
                wiVar.d = i;
                wiVar.f = j4;
                wiVar.n = j3;
                wiVar.q = 6;
                if (q6.r(jB4, wiVar) == c40Var) {
                    return c40Var;
                }
                return lh3.a;
            case wb2.LONG_FIELD_NUMBER /* 4 */:
                j3 = wiVar.n;
                j7 = wiVar.f;
                i3 = wiVar.d;
                str2 = wiVar.c;
                cj0.I(obj);
                c40Var = c40Var2;
                j = 1000;
                j4 = j7;
                i = i3;
                if (d31.a(5)) {
                    jB3 = d31.b(10000L, 4000L, 4000L, 25000L);
                    y(str2, y22.l("Distraction pause ", jB3 / j, "s"));
                    wiVar.a = null;
                    wiVar.b = null;
                    wiVar.c = null;
                    wiVar.d = i;
                    wiVar.f = j4;
                    wiVar.n = j3;
                    wiVar.q = 5;
                    c40Var = c40Var;
                    if (q6.r(jB3, wiVar) == c40Var) {
                        return c40Var;
                    }
                    j8 = j3;
                    i4 = i;
                    i = i4;
                    j3 = j8;
                }
                jB4 = d31.b(400L, 150L, 150L, 1000L);
                wiVar.a = null;
                wiVar.b = null;
                wiVar.c = null;
                wiVar.d = i;
                wiVar.f = j4;
                wiVar.n = j3;
                wiVar.q = 6;
                if (q6.r(jB4, wiVar) == c40Var) {
                    return c40Var;
                }
                return lh3.a;
            case wb2.STRING_FIELD_NUMBER /* 5 */:
                j8 = wiVar.n;
                long j15 = wiVar.f;
                i4 = wiVar.d;
                cj0.I(obj);
                j4 = j15;
                c40Var = c40Var2;
                i = i4;
                j3 = j8;
                jB4 = d31.b(400L, 150L, 150L, 1000L);
                wiVar.a = null;
                wiVar.b = null;
                wiVar.c = null;
                wiVar.d = i;
                wiVar.f = j4;
                wiVar.n = j3;
                wiVar.q = 6;
                if (q6.r(jB4, wiVar) == c40Var) {
                    return c40Var;
                }
                return lh3.a;
            case wb2.STRING_SET_FIELD_NUMBER /* 6 */:
                cj0.I(obj);
                return lh3.a;
            default:
                g.n("call to 'resume' before 'invoke' with coroutine");
                return null;
        }
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object m(u20 u20Var) {
        xi xiVar;
        if (u20Var instanceof xi) {
            xiVar = (xi) u20Var;
            int i = xiVar.c;
            if ((i & Integer.MIN_VALUE) != 0) {
                xiVar.c = i - Integer.MIN_VALUE;
            } else {
                xiVar = new xi(this, u20Var);
            }
        } else {
            xiVar = new xi(this, u20Var);
        }
        Object objZ = xiVar.a;
        int i2 = xiVar.c;
        if (i2 == 0) {
            cj0.I(objZ);
            if (((EngineState) this.j.getValue()).getStatus() == SessionStatus.RUNNING) {
                return Boolean.FALSE;
            }
            xiVar.c = 1;
            objZ = mi0.z(this.g.b, xiVar);
            c40 c40Var = c40.a;
            if (objZ == c40Var) {
                return c40Var;
            }
        } else {
            if (i2 != 1) {
                g.n("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            cj0.I(objZ);
        }
        g3 g3Var = (g3) objZ;
        if (g3Var == null) {
            return Boolean.FALSE;
        }
        r(g3Var.c, g3Var.a, g3Var.b);
        c(new AutomationEvent.Info("Session recovered after restart"));
        return Boolean.TRUE;
    }

    public final void n() {
        Object next;
        u03 u03Var;
        Object value;
        EngineState engineState;
        LinkedHashMap linkedHashMap;
        t53 t53Var = this.b;
        Iterator it = t53Var.a().iterator();
        boolean zHasNext = it.hasNext();
        ConcurrentHashMap concurrentHashMap = this.C;
        if (zHasNext) {
            next = it.next();
            if (it.hasNext()) {
                TabState tabState = (TabState) concurrentHashMap.get((String) next);
                int index = tabState != null ? tabState.getIndex() : 0;
                do {
                    Object next2 = it.next();
                    TabState tabState2 = (TabState) concurrentHashMap.get((String) next2);
                    int index2 = tabState2 != null ? tabState2.getIndex() : 0;
                    if (index < index2) {
                        next = next2;
                        index = index2;
                    }
                } while (it.hasNext());
            }
        } else {
            next = null;
        }
        String str = (String) next;
        if (str != null) {
            ConcurrentHashMap concurrentHashMap2 = this.i;
            ca1 ca1Var = (ca1) concurrentHashMap2.get(str);
            if (ca1Var != null) {
                ca1Var.cancel(null);
            }
            concurrentHashMap2.remove(str);
            t53Var.c(str);
            this.A.remove(str);
            this.B.remove(str);
            concurrentHashMap.remove(str);
            do {
                u03Var = this.j;
                value = u03Var.getValue();
                engineState = (EngineState) value;
                Map<String, TabRealTimeState> tabStates = engineState.getTabStates();
                tabStates.getClass();
                linkedHashMap = new LinkedHashMap(tabStates);
                linkedHashMap.remove(str);
            } while (!u03Var.i(value, EngineState.copy$default(engineState, null, null, null, linkedHashMap.size(), linkedHashMap.size(), 0, 0, 0L, null, linkedHashMap, false, null, null, false, null, 0, 0L, 130535, null)));
        }
    }

    public final void o(String str, String str2) {
        Object value;
        EngineState engineState;
        AutomationConfig automationConfig = this.s;
        if (automationConfig != null) {
            u03 u03Var = this.j;
            if (((EngineState) u03Var.getValue()).getStatus() == SessionStatus.RUNNING) {
                return;
            }
            do {
                value = u03Var.getValue();
                engineState = (EngineState) value;
            } while (!u03Var.i(value, EngineState.copy$default(engineState, null, SessionStatus.RUNNING, null, 0, 0, 0, 0, engineState.getStartedAt() == 0 ? System.currentTimeMillis() : engineState.getStartedAt(), "Resuming...", null, false, null, null, false, null, 0, 0L, 130685, null)));
            c(new AutomationEvent.SessionResumed(str));
            q6.G(this.h, null, null, new i8(this, automationConfig, str, str2, null, (byte) 1), 3);
        }
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0017  */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x006d, code lost:
    
        if (r1.b(null, r2) == r3) goto L28;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object p(defpackage.u20 r25) {
        /*
            r24 = this;
            r0 = r24
            r1 = r25
            boolean r2 = r1 instanceof defpackage.yi
            if (r2 == 0) goto L17
            r2 = r1
            yi r2 = (defpackage.yi) r2
            int r3 = r2.c
            r4 = -2147483648(0xffffffff80000000, float:-0.0)
            r5 = r3 & r4
            if (r5 == 0) goto L17
            int r3 = r3 - r4
            r2.c = r3
            goto L1c
        L17:
            yi r2 = new yi
            r2.<init>(r0, r1)
        L1c:
            java.lang.Object r1 = r2.a
            c40 r3 = defpackage.c40.a
            int r4 = r2.c
            r5 = 3
            r6 = 2
            r7 = 1
            r8 = 0
            if (r4 == 0) goto L40
            if (r4 == r7) goto L3c
            if (r4 == r6) goto L38
            if (r4 != r5) goto L32
            defpackage.cj0.I(r1)
            goto L70
        L32:
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            defpackage.g.n(r0)
            return r8
        L38:
            defpackage.cj0.I(r1)
            return r1
        L3c:
            defpackage.cj0.I(r1)
            goto L4d
        L40:
            defpackage.cj0.I(r1)
            ox0 r1 = r0.c
            r2.c = r7
            java.lang.Object r1 = r1.g(r2)
            if (r1 == r3) goto L6f
        L4d:
            com.autopilot.app.domain.model.ProxyInfo r1 = (com.autopilot.app.domain.model.ProxyInfo) r1
            if (r1 == 0) goto L5b
            r2.c = r6
            r1 = 0
            java.lang.Object r0 = r0.a(r1, r2)
            if (r0 == r3) goto L6f
            return r0
        L5b:
            com.autopilot.app.domain.model.AutomationEvent$Info r1 = new com.autopilot.app.domain.model.AutomationEvent$Info
            java.lang.String r4 = "Proxy rotation failed: no healthy proxy available"
            r1.<init>(r4)
            r0.c(r1)
            og2 r1 = defpackage.w91.e
            r2.c = r5
            java.lang.Object r1 = r1.b(r8, r2)
            if (r1 != r3) goto L70
        L6f:
            return r3
        L70:
            t53 r1 = r0.b
            r1.g = r8
            u03 r0 = r0.j
        L76:
            java.lang.Object r1 = r0.getValue()
            r2 = r1
            com.autopilot.app.domain.model.EngineState r2 = (com.autopilot.app.domain.model.EngineState) r2
            r22 = 123903(0x1e3ff, float:1.73625E-40)
            r23 = 0
            r3 = 0
            r4 = 0
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            r9 = 0
            r10 = 0
            r12 = 0
            r13 = 0
            r14 = 0
            java.lang.String r15 = ""
            java.lang.String r16 = ""
            r17 = 0
            r18 = 0
            r19 = 0
            r20 = 0
            com.autopilot.app.domain.model.EngineState r2 = com.autopilot.app.domain.model.EngineState.copy$default(r2, r3, r4, r5, r6, r7, r8, r9, r10, r12, r13, r14, r15, r16, r17, r18, r19, r20, r22, r23)
            boolean r1 = r0.i(r1, r2)
            if (r1 == 0) goto L76
            java.lang.Boolean r0 = java.lang.Boolean.FALSE
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ij.p(u20):java.lang.Object");
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object q(u20 u20Var) {
        zi ziVar;
        if (u20Var instanceof zi) {
            ziVar = (zi) u20Var;
            int i = ziVar.c;
            if ((i & Integer.MIN_VALUE) != 0) {
                ziVar.c = i - Integer.MIN_VALUE;
            } else {
                ziVar = new zi(this, u20Var);
            }
        } else {
            ziVar = new zi(this, u20Var);
        }
        Object obj = ziVar.a;
        int i2 = ziVar.c;
        t20 t20Var = null;
        if (i2 == 0) {
            cj0.I(obj);
            x("Fetching proxy...");
            ox0 ox0Var = this.c;
            j03 j03Var = ox0Var.s;
            if (j03Var == null || !j03Var.isActive()) {
                ox0Var.s = q6.G(ox0Var.b, null, null, new g8(ox0Var, t20Var, (byte) 4), 3);
            }
            ziVar.c = 1;
            Object objA = a(true, ziVar);
            Object obj2 = c40.a;
            if (objA == obj2) {
                return obj2;
            }
        } else {
            if (i2 != 1) {
                g.n("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            cj0.I(obj);
        }
        return lh3.a;
    }

    public final void r(AutomationConfig automationConfig, String str, String str2) {
        u03 u03Var = this.j;
        if (((EngineState) u03Var.getValue()).getStatus() == SessionStatus.RUNNING && rr3.l(((EngineState) u03Var.getValue()).getSessionId(), str)) {
            return;
        }
        this.s = automationConfig;
        ArrayList arrayListE0 = ru.e0(su.A(str2), automationConfig.getUrls());
        ArrayList arrayList = new ArrayList(su.m(arrayListE0, 10));
        int size = arrayListE0.size();
        int i = 0;
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayListE0.get(i2);
            i2++;
            arrayList.add(z13.A0((String) obj).toString());
        }
        ArrayList arrayList2 = new ArrayList();
        int size2 = arrayList.size();
        while (i < size2) {
            Object obj2 = arrayList.get(i);
            i++;
            if (!z13.g0((String) obj2)) {
                arrayList2.add(obj2);
            }
        }
        this.y = ru.o0(new LinkedHashSet(arrayList2));
        this.t = System.currentTimeMillis();
        String id = TimeZone.getDefault().getID();
        id.getClass();
        this.u = id;
        ki kiVar = new ki(this, str, str2, automationConfig, null, (byte) 1);
        ij ijVar = this;
        s20 s20Var = ijVar.h;
        q6.G(s20Var, null, null, kiVar, 3);
        while (true) {
            Object value = u03Var.getValue();
            s20 s20Var2 = s20Var;
            u03 u03Var2 = u03Var;
            if (u03Var2.i(value, new EngineState(str, SessionStatus.RUNNING, str2, 0, 0, 0, 0, ijVar.t, "Initializing...", null, false, null, null, false, null, 0, 0L, 130680, null))) {
                c(new AutomationEvent.SessionStarted(str, str2, automationConfig.getTabCount()));
                this.n = q6.G(s20Var2, null, null, new bj(automationConfig, this, str, str2, null), 3);
                return;
            } else {
                ijVar = this;
                u03Var = u03Var2;
                s20Var = s20Var2;
            }
        }
    }

    public final void s() {
        String sessionId = ((EngineState) this.j.getValue()).getSessionId();
        boolean z = sessionId.length() > 0;
        j03 j03Var = this.n;
        if (j03Var != null) {
            j03Var.cancel(null);
        }
        j03 j03Var2 = this.o;
        if (j03Var2 != null) {
            j03Var2.cancel(null);
        }
        j03 j03Var3 = this.p;
        if (j03Var3 != null) {
            j03Var3.cancel(null);
        }
        j03 j03Var4 = this.q;
        if (j03Var4 != null) {
            j03Var4.cancel(null);
        }
        j03 j03Var5 = this.r;
        if (j03Var5 != null) {
            j03Var5.cancel(null);
        }
        this.n = null;
        this.o = null;
        this.p = null;
        this.q = null;
        this.r = null;
        Collection<ca1> collectionValues = this.i.values();
        collectionValues.getClass();
        for (ca1 ca1Var : collectionValues) {
            ca1Var.getClass();
            ca1Var.cancel(null);
        }
        this.i.clear();
        t53 t53Var = this.b;
        Collection<w91> collectionValues2 = t53Var.e.values();
        collectionValues2.getClass();
        for (w91 w91Var : collectionValues2) {
            w91Var.getClass();
            new Handler(Looper.getMainLooper()).post(new y(w91Var, (byte) 10));
        }
        t53Var.e.clear();
        t53Var.f.clear();
        t53Var.d.a.clear();
        t53Var.g = null;
        this.A.clear();
        this.B.clear();
        this.C.clear();
        this.z.clear();
        this.w.set(0);
        this.v = null;
        ox0 ox0Var = this.c;
        j03 j03Var6 = ox0Var.s;
        if (j03Var6 != null) {
            j03Var6.cancel(null);
        }
        ox0Var.s = null;
        q6.G(this.h, null, null, new cj(2, null), 3);
        oq1 oq1Var = this.f;
        j03 j03Var7 = oq1Var.b;
        if (j03Var7 != null) {
            j03Var7.cancel(null);
        }
        oq1Var.b = null;
        String str = this.u;
        this.u = "";
        if (str.length() > 0) {
            q6.G(this.h, null, null, new dj(this, str, null), 3);
        }
        c(new AutomationEvent.SessionStopped(sessionId));
        u03 u03Var = this.j;
        while (true) {
            Object value = u03Var.getValue();
            u03 u03Var2 = u03Var;
            boolean z2 = z;
            if (u03Var2.i(value, new EngineState(sessionId, SessionStatus.STOPPED, null, 0, 0, 0, 0, 0L, "Stopped", null, false, null, null, false, null, 0, 0L, 130812, null))) {
                q6.G(this.h, null, null, new ej(z2, this, sessionId, null), 3);
                this.s = null;
                return;
            } else {
                u03Var = u03Var2;
                z = z2;
            }
        }
    }

    /* JADX WARN: Can't wrap try/catch for region: R(4:47|24|(1:26)(2:50|35)|22) */
    /* JADX WARN: Code duplicated, block: B:31:0x0080  */
    /* JADX WARN: Code duplicated, block: B:32:0x0087  */
    /* JADX WARN: Code duplicated, block: B:7:0x0017  */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0071, code lost:
    
        r0 = e;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0072, code lost:
    
        r12 = r2;
        r2 = r10;
        r10 = r11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00ae, code lost:
    
        if (defpackage.q6.r(r10, r2) == r9) goto L35;
     */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:34:0x00ae -> B:13:0x0036). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object t(java.lang.String r19, defpackage.by0 r20, defpackage.u20 r21) {
        /*
            r18 = this;
            r1 = r18
            r0 = r21
            boolean r2 = r0 instanceof defpackage.fj
            if (r2 == 0) goto L17
            r2 = r0
            fj r2 = (defpackage.fj) r2
            int r3 = r2.f
            r4 = -2147483648(0xffffffff80000000, float:-0.0)
            r5 = r3 & r4
            if (r5 == 0) goto L17
            int r3 = r3 - r4
            r2.f = r3
            goto L1c
        L17:
            fj r2 = new fj
            r2.<init>(r1, r0)
        L1c:
            java.lang.Object r0 = r2.d
            int r3 = r2.f
            r4 = 2000(0x7d0, double:9.88E-321)
            r6 = 2
            r7 = 0
            r8 = 1
            c40 r9 = defpackage.c40.a
            if (r3 == 0) goto L4e
            if (r3 == r8) goto L40
            if (r3 != r6) goto L3a
            long r10 = r2.c
            by0 r3 = r2.b
            java.lang.String r12 = r2.a
            defpackage.cj0.I(r0)
        L36:
            r0 = r2
            r2 = r12
            goto Lb1
        L3a:
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            defpackage.g.n(r0)
            return r7
        L40:
            long r10 = r2.c
            by0 r3 = r2.b
            java.lang.String r12 = r2.a
            defpackage.cj0.I(r0)     // Catch: java.lang.Exception -> L4c java.util.concurrent.CancellationException -> Lbe
            r10 = r2
            r2 = r12
            goto L6f
        L4c:
            r0 = move-exception
            goto L78
        L4e:
            defpackage.cj0.I(r0)
            r3 = r20
            r10 = r2
            r11 = r4
            r2 = r19
        L57:
            s30 r0 = r10.getContext()
            boolean r0 = defpackage.ci0.J(r0)
            if (r0 == 0) goto Lbe
            r10.a = r2     // Catch: java.lang.Exception -> L71 java.util.concurrent.CancellationException -> Lbe
            r10.b = r3     // Catch: java.lang.Exception -> L71 java.util.concurrent.CancellationException -> Lbe
            r10.c = r11     // Catch: java.lang.Exception -> L71 java.util.concurrent.CancellationException -> Lbe
            r10.f = r8     // Catch: java.lang.Exception -> L71 java.util.concurrent.CancellationException -> Lbe
            java.lang.Object r0 = r3.invoke(r10)     // Catch: java.lang.Exception -> L71 java.util.concurrent.CancellationException -> Lbe
            if (r0 == r9) goto Lb0
        L6f:
            r11 = r4
            goto L57
        L71:
            r0 = move-exception
            r16 = r11
            r12 = r2
            r2 = r10
            r10 = r16
        L78:
            com.autopilot.app.domain.model.AutomationEvent$Info r13 = new com.autopilot.app.domain.model.AutomationEvent$Info
            java.lang.String r0 = r0.getMessage()
            if (r0 == 0) goto L87
            r14 = 80
            java.lang.String r0 = defpackage.z13.z0(r14, r0)
            goto L88
        L87:
            r0 = r7
        L88:
            java.lang.StringBuilder r14 = new java.lang.StringBuilder
            r14.<init>()
            r14.append(r12)
            java.lang.String r15 = " restarted after error: "
            r14.append(r15)
            r14.append(r0)
            java.lang.String r0 = r14.toString()
            r13.<init>(r0)
            r1.c(r13)
            r2.a = r12
            r2.b = r3
            r2.c = r10
            r2.f = r6
            java.lang.Object r0 = defpackage.q6.r(r10, r2)
            if (r0 != r9) goto L36
        Lb0:
            return r9
        Lb1:
            long r10 = r10 << r8
            r12 = 60000(0xea60, double:2.9644E-319)
            int r14 = (r10 > r12 ? 1 : (r10 == r12 ? 0 : -1))
            if (r14 <= 0) goto Lbb
            r11 = r12
            goto Lbc
        Lbb:
            r11 = r10
        Lbc:
            r10 = r0
            goto L57
        Lbe:
            lh3 r0 = defpackage.lh3.a
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ij.t(java.lang.String, by0, u20):java.lang.Object");
    }

    /* JADX WARN: Code duplicated, block: B:161:0x04f8 A[LOOP:1: B:158:0x04a6->B:161:0x04f8, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:219:0x04e7 A[EDGE_INSN: B:219:0x04e7->B:160:0x04e7 BREAK  A[LOOP:1: B:158:0x04a6->B:161:0x04f8], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:7:0x0017  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:138:0x0411 -> B:154:0x0454). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:156:0x0494 -> B:157:0x04a4). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:95:0x0319 -> B:96:0x0334). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached at block B:161:0x04f8
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    public final void u(java.lang.String r63, defpackage.u20 r64) {
        /*
            Method dump skipped, instruction units count: 1277
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ij.u(java.lang.String, u20):void");
    }

    public final void v() {
        u03 u03Var;
        Object value;
        t53 t53Var;
        Collection collectionValues = this.A.values();
        collectionValues.getClass();
        Iterator it = collectionValues.iterator();
        int i = 0;
        while (it.hasNext()) {
            i += ((AtomicInteger) it.next()).get();
        }
        Collection collectionValues2 = this.B.values();
        collectionValues2.getClass();
        Iterator it2 = collectionValues2.iterator();
        int i2 = 0;
        while (it2.hasNext()) {
            i2 += ((AtomicInteger) it2.next()).get();
        }
        do {
            u03Var = this.j;
            value = u03Var.getValue();
            t53Var = this.b;
        } while (!u03Var.i(value, EngineState.copy$default((EngineState) value, null, null, null, t53Var.e.size(), t53Var.e.size(), i, i2, 0L, null, null, false, null, null, false, null, 0, 0L, 130951, null)));
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object w(u20 u20Var) {
        hj hjVar;
        if (u20Var instanceof hj) {
            hjVar = (hj) u20Var;
            int i = hjVar.c;
            if ((i & Integer.MIN_VALUE) != 0) {
                hjVar.c = i - Integer.MIN_VALUE;
            } else {
                hjVar = new hj(this, u20Var);
            }
        } else {
            hjVar = new hj(this, u20Var);
        }
        Object obj = hjVar.a;
        int i2 = hjVar.c;
        if (i2 != 0 && i2 != 1 && i2 != 2) {
            g.n("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        cj0.I(obj);
        while (ci0.J(hjVar.getContext())) {
            Set setA = this.b.a();
            boolean zIsEmpty = setA.isEmpty();
            c40 c40Var = c40.a;
            if (zIsEmpty) {
                hjVar.c = 1;
                if (q6.r(2000L, hjVar) == c40Var) {
                    return c40Var;
                }
            } else {
                t0 t0Var = jg2.a;
                String str = (String) ru.g0(setA);
                this.v = str;
                long jB = d31.b(45000L, 20000L, 15000L, 90000L);
                String str2 = this.v;
                if (str2 == null) {
                    str2 = "";
                }
                c(new AutomationEvent.TabSwitched(str2, str));
                c(new AutomationEvent.Info("Tab Coordinator: Focus switched to " + str + " for " + (jB / 1000) + "s"));
                hjVar.c = 2;
                if (q6.r(jB, hjVar) == c40Var) {
                    return c40Var;
                }
            }
        }
        return lh3.a;
    }

    public final void x(String str) {
        u03 u03Var;
        Object value;
        do {
            u03Var = this.j;
            value = u03Var.getValue();
        } while (!u03Var.i(value, EngineState.copy$default((EngineState) value, null, null, null, 0, 0, 0, 0, 0L, str, null, false, null, null, false, null, 0, 0L, 130815, null)));
    }

    public final void y(String str, String str2) {
        u03 u03Var;
        Object value;
        EngineState engineState;
        LinkedHashMap linkedHashMap;
        String currentActivity;
        do {
            u03Var = this.j;
            value = u03Var.getValue();
            engineState = (EngineState) value;
            Map<String, TabRealTimeState> tabStates = engineState.getTabStates();
            tabStates.getClass();
            linkedHashMap = new LinkedHashMap(tabStates);
            TabRealTimeState tabRealTimeState = (TabRealTimeState) linkedHashMap.get(str);
            if (tabRealTimeState != null) {
                long jCurrentTimeMillis = System.currentTimeMillis();
                AtomicInteger atomicInteger = (AtomicInteger) this.A.get(str);
                int i = atomicInteger != null ? atomicInteger.get() : 0;
                AtomicInteger atomicInteger2 = (AtomicInteger) this.B.get(str);
                linkedHashMap.put(str, TabRealTimeState.copy$default(tabRealTimeState, null, 0, null, i, atomicInteger2 != null ? atomicInteger2.get() : 0, str2, jCurrentTimeMillis, 7, null));
            }
            if (tabRealTimeState != null) {
                currentActivity = "Tab " + (tabRealTimeState.getIndex() + 1) + ": " + str2;
            } else {
                currentActivity = engineState.getCurrentActivity();
            }
        } while (!u03Var.i(value, EngineState.copy$default(engineState, null, null, null, 0, 0, 0, 0, 0L, currentActivity, linkedHashMap, false, null, null, false, null, 0, 0L, 130303, null)));
    }
}
