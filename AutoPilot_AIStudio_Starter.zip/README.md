# AutoPilot AI Studio starter pack

This is an upload-oriented starter pack, not a completed APK or verified 1:1 reconstruction.

Contents:
- `android-project/`: current Kotlin Android project supplied by the user, without transient Gradle cache.
- `original-reference/`: selected original decompiled classes and manifest for focused comparison.
- `AI_STUDIO_MASTER_PROMPT.md`: task instructions for AI Studio.

Limitations:
- Decompiled code is not pristine source and may need manual porting.
- The original manifest does not declare Android VpnService in the supplied manifest; WebView proxying must not be mislabeled as device-wide VPN.
- Public proxy sources can stop working or rate-limit requests.
- Private server logic, Firebase rules, API credentials and secrets cannot be recovered reliably from an APK.
- This pack does not claim that all features are already implemented or live.
