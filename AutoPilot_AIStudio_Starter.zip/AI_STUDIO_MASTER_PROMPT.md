# MASTER TASK — Reconstruct AutoPilot faithfully from supplied references

You are given:
- `android-project/`: current Android Studio / AI Studio Kotlin project.
- `original-reference/`: selected decompiled source files and original manifest from the original APK.

Goal: make the current project match the original APK's visible UI and verifiable behavior as closely as possible. Do not invent missing behavior.

## Mandatory first step
Inspect every file in both folders. Create a concrete comparison report with:
- original screen/navigation inventory,
- each original feature and exact supporting class/method/resource,
- current implementation file,
- missing/different parts,
- external dependencies or credentials that cannot be recovered from an APK.

Do not start by redesigning the UI. Preserve original names, screen order, labels, defaults, colors, controls, and interaction flows based on the supplied source/assets.

## Implementation requirements
1. Keep the existing project buildable; modify incrementally.
2. Port original proxy manager and fetching logic from `ox0.java` / `jx0.java` into clean Kotlin, preserving only endpoints and behavior actually supported by source.
3. Implement real proxy validation and transparent health states. Never fabricate proxy entries, country data, or healthy counts. Handle dead public proxy sources, timeouts, rate limits and malformed responses.
4. Recreate country/region selection based on actual original supported country data.
5. Recreate original automation controls and lifecycle only where source confirms them. Keep user-controlled limits, visible status, stop/pause controls, and Android foreground-service requirements.
6. Recreate root/device settings only where source confirms them and Android permission/root access permits. Never claim system-wide spoofing when it is not actually applied.
7. Inspect the original manifest. The supplied original manifest does not show an Android `VpnService` declaration. Do NOT call WebView proxy override a full-device VPN. If no authorized VPN server and protocol config is supplied, implement only accurately labeled app/WebView proxy routing; provide a clearly disabled VPN-service placeholder rather than a fake tunnel.
8. Do not invent Firebase secrets, private API keys, backend URLs, database rules, or server-side code. If a required backend is absent, expose a setup screen and document exactly what the owner must provide.
9. Do not include hidden tracking, credential collection, referral manipulation, ad fraud, traffic inflation, or evasion of third-party anti-abuse systems.
10. Run Gradle build/tests if the environment permits. Fix compilation errors. Report actual build/test results; never claim unrun tests passed.

## Deliverables
- Complete editable Android Studio project.
- `FEATURE_PARITY_REPORT.md` with verified / partial / unavailable statuses and citations to local filenames/classes.
- `BACKEND_SETUP.md` listing only actual required owner-provided configuration.
- Build instructions and exact APK output path if successfully built.
- A short AI Studio change log.

Important: Decompiled JADX output is not the original source tree and may contain incorrect control flow, missing names, or incomplete code. Treat it as evidence, not blindly compilable code. The final app must not claim 1:1 parity until every feature is implemented and tested on a real device.
